# Prompt — PORTRAIT_NORGARD_TRESKAL_FARMER_MALE_001

## Estado

APPROVED

## Prompt exacto utilizado

```text
Create a canonical NPC portrait for Nimroel based on the current visual bibles.

Subject: a male peasant / farmer from Treskal, in Norgard. Adult, roughly 35–50 years old. He is a believable ordinary rural worker, not a hero, not a noble, not a fantasy archetype.

Use the current portrait rules with two layers explicitly resolved:
presentation_state_level: 2
clothing_patina_grade: C

Meaning: he is in the middle of a real workday or has just paused during agricultural work. He should show honest, localized signs of labor, but not exaggerated filth. His body and clothing must feel physically real and logically used.

Format: vertical 4:5 portrait, medium bust / broad bust framing. Character is the clear focus. Background must be contextual and softly blurred.

Visual style: naturalistic cinematic realism, grounded fantasy, physically believable materials, no generic MMO look, no fashion-photo look, no poster pose, no Viking cliché.

Culture and place: Norgard, specifically Treskal. The background should subtly suggest the rural edge of Treskal: farm plots, fences, stone-and-wood structures, dark slate roofs, and a distant soft impression of the town. Keep the background secondary and out of focus.

Appearance: weathered adult male with a believable rural face, rough skin from sun and wind, practical medium-length brown hair, short to medium beard, serious calm expression, direct or slightly off-camera gaze. He should look human, lived-in, and capable, not glamorous.

Clothing: simple rural work clothes in muted, realistic tones. A light linen shirt in off-white / bone / aged cream or washed beige, definitely not pure bright white, plus a darker worn wool vest or sleeveless outer layer. The garments must show pátina C: visible everyday use, slightly dulled tones, persistent wrinkles, marked cuffs or areas of friction, and a clear sense of repeated wear. The clothing may be reasonably clean in general but must not look new.

Work traces: because he is at level 2, add localized dirt and work marks that come specifically from farm labor. Show earth and soil on forearms, hands, cuffs, lower sleeves, and some splashes or smudges on the shirt and work clothes. The face may remain comparatively cleaner than the hands and clothing. If a tool is visible, it can be a wooden farm tool handle that he rests on during a brief pause.

Important material rule: cleanliness of the body does not erase the material memory of the clothes. The shirt and vest must retain everyday wear even if he has not been rendered as filthy.

Lighting: believable natural daylight, soft cinematic lighting, rich but restrained color, clear texture in skin, linen, wool, wood, and soil.

Negative guidance: no armor, no weapons, no heraldry, no jewelry of status, no religious symbols, no magic, no glowing elements, no theatrical pose, no text, no modern elements.

Output: one polished canonical portrait suitable as the first approved farmer male portrait from Treskal in the Nimroel visual workflow.
```
