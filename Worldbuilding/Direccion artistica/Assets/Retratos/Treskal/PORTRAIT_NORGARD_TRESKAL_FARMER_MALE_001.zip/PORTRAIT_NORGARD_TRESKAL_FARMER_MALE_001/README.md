# PORTRAIT_NORGARD_TRESKAL_FARMER_MALE_001

## Nombre

**Campesino de Treskal**

## Clasificación

- **Categoría:** portrait
- **Tipo:** NPC genérico
- **Reino / cultura:** Norgard
- **Localización:** Treskal
- **Pool:** farmer_male
- **Estado:** APPROVED
- **Fecha de aprobación:** 2026-09-24

## Descripción

Primer retrato aprobado de un **campesino varón de Treskal** dentro del workflow visual de Nimroel.

El retrato representa a un trabajador rural corriente de Norgard, en pausa durante una jornada agrícola. La imagen aplica correctamente las dos capas vigentes de las biblias de retrato:

- **presentation_state_level = 2**
- **clothing_patina_grade = C**

Es decir: se encuentra en plena jornada de trabajo, con suciedad localizada y lógica de la faena, mientras la ropa muestra una pátina cotidiana de uso real, sin parecer recién estrenada ni artificialmente impoluta.

## Archivos incluidos

- `PORTRAIT_NORGARD_TRESKAL_FARMER_MALE_001.png`
- `PROMPT.md`
- `metadata.json`
- `manifest.json`
- `README.md`
- `PORTRAIT_NORGARD_TRESKAL_FARMER_MALE_001.zip`

## Observaciones canónicas

- La prenda clara respeta la regla de **ropa usada**: hueso / beige envejecido, no blanco puro.
- Las marcas de tierra aparecen sobre todo en manos, antebrazos, puños y mangas, de forma coherente con la actividad.
- El fondo sugiere el entorno rural de Treskal sin convertir el retrato en una escena narrativa completa.
