# 25 · SISTEMA DE NPC

## Qué es

Gestiona el comportamiento autónomo de los personajes no controlados por el jugador. Debe permitir que los NPC de Nimroel mantengan objetivos, prioridades, rutinas y procesos de decisión propios, de forma que el mundo siga funcionando aunque el jugador no intervenga directamente. Sus decisiones deberán transformarse en solicitudes de acción sometidas a las mismas reglas que las acciones equivalentes del jugador; los sistemas propietarios conservarán la autoridad sobre relaciones, comercio, salud, propiedad, delitos, combate y cualquier otro cambio de dominio.

## Debe permitir

- asignar objetivos actuales a cada NPC;
- priorizar necesidades, obligaciones e intereses;
- ejecutar rutinas diarias;
- gestionar horarios;
- desplazarse entre localizaciones;
- trabajar;
- descansar;
- comerciar;
- relacionarse con otros personajes;
- reaccionar ante acontecimientos;
- modificar relaciones según experiencias;
- recordar sucesos relevantes;
- actuar según personalidad y motivaciones;
- reaccionar de forma distinta ante una misma situación;
- tomar decisiones dentro de límites definidos y convertirlas en solicitudes al Sistema de Acciones, Reglas, Condiciones, Efectos y Validación de Gameplay;
- abandonar objetivos cuando las circunstancias cambien;
- recibir nuevos objetivos de sistemas superiores;
- ejecutar comportamientos de corto, medio y largo plazo;
- integrarse con profesiones;
- integrarse con organizaciones y facciones;
- participar en economía;
- cometer delitos o reaccionar ante ellos;
- participar en conflictos;
- participar en guerras;
- formar parejas y familias;
- tener descendencia;
- emigrar o cambiar de residencia;
- ascender o perder posición social;
- adquirir o perder propiedades;
- enfermar, resultar herido y morir;
- reaccionar ante amenazas;
- huir, combatir, negociar o pedir ayuda según contexto;
- compartir información con otros personajes;
- transmitir rumores;
- desconocer información que nunca haya recibido;
- actuar basándose en información incorrecta;
- mantener autonomía incluso cuando el jugador se encuentra lejos;
- utilizar distintos niveles de simulación según importancia y proximidad;
- evitar ejecutar IA completa para todos los habitantes simultáneamente;
- permitir simulación simplificada en segundo plano;
- recuperar un nivel de detalle mayor cuando un NPC vuelva a ser relevante;
- coordinarse con la representación visual del NPC cuando esté presente en escena;
- existir y evolucionar aunque su Actor de UE5 no esté cargado;
- integrarse con navegación y movimiento;
- integrarse con diálogos;
- permitir que el Director priorice oportunidades o contexto sin controlar directamente las decisiones ni forzar acciones de los NPC;
- permitir que Magíster/IA proponga objetivos o planes cuando corresponda, sin convertirse en autoridad del estado del mundo;
- mantener comportamiento lógico equivalente en Windows y Android.
## Depende de

- Núcleo de Partida
- Sistema de Estado del Mundo
- Sistema de Tiempo
- Sistema de Entidades e Identidad
- Sistema de Personajes
## Lo utilizan

- Director
- Relationships
- Knowledge System
- Organizations
- Economy
- Crime System
- Professions
- Generations
- Combat
- Dialogues
- Travel
- Events
- Quests
- Reputation
- Maps
- Partida Maestra/Magíster
## Reutilización

RPG Core configurable. La arquitectura de autonomía, objetivos, rutinas, toma de decisiones, niveles de simulación y comportamiento deberá ser reutilizable. Los comportamientos, profesiones, culturas, reglas sociales y condicionantes específicos de Nimroel deberán introducirse mediante datos, reglas y módulos configurables.

## Documentación técnica

Obligatoria. Codex deberá crear y mantener la documentación técnica del sistema a medida que lo implemente y modifique. La documentación deberá reflejar exclusivamente la implementación real existente en el repositorio e incluir, como mínimo:

- arquitectura;
- clases y componentes;
- archivos;
- estructuras y enums;
- API pública;
- flujo de datos;
- inicialización;
- dependencias;
- comunicación con otros sistemas;
- persistencia;
- decisiones técnicas relevantes;
- diferencias entre Windows y Android cuando existan;
- pruebas y validaciones;
- limitaciones conocidas;
- elementos pertenecientes al RPG Core reutilizable;
- dependencias específicas de Nimroel;
- instrucciones necesarias para portar o reutilizar el sistema en otro videojuego. La documentación deberá mantenerse actualizada y versionada junto con el código.
## Estado

Pendiente
