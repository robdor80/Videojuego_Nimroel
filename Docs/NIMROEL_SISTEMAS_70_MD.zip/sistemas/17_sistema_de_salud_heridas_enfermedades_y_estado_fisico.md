# 17 · SISTEMA DE SALUD, HERIDAS, ENFERMEDADES Y ESTADO FÍSICO

## Qué es

Gestiona el estado fisico de los personajes y las alteraciones que pueden afectar a su capacidad para vivir, desplazarse, trabajar, combatir o realizar otras actividades. Debe permitir representar heridas, enfermedades, intoxicaciones, agotamiento, recuperación y muerte de forma persistente e integrada con el resto de sistemas, evitando reducir la salud a una única barra de puntos de vida.

## Debe permitir

- mantener un estado de salud general;
- gestionar daño recibido;
- distinguir diferentes tipos de daño;
- gestionar heridas leves;
- gestionar heridas graves;
- gestionar heridas críticas;
- gestionar heridas permanentes;
- gestionar lesiones temporales;
- gestionar incapacidades;
- gestionar hemorragias;
- gestionar quemaduras;
- gestionar fracturas;
- gestionar traumatismos;
- gestionar heridas internas cuando el nivel de simulación lo requiera;
- gestionar infecciones;
- gestionar enfermedades;
- gestionar enfermedades contagiosas cuando corresponda;
- gestionar intoxicaciones;
- gestionar envenenamientos;
- gestionar efectos de sustancias;
- gestionar agotamiento;
- gestionar fatiga;
- gestionar debilidad;
- gestionar pérdida de consciencia;
- gestionar estados de inmovilización;
- gestionar dolor cuando sea relevante para la lógica de comportamiento;
- permitir distintos niveles de gravedad;
- permitir evolución de una lesión con el tiempo;
- permitir empeoramiento sin tratamiento;
- permitir recuperación natural;
- permitir recuperación mediante descanso;
- permitir tratamientos;
- permitir curación mediante objetos;
- permitir curación mediante profesionales;
- permitir tratamientos prolongados;
- permitir intervenciones específicas según el universo;
- permitir tratamientos incorrectos;
- permitir efectos secundarios;
- permitir complicaciones;
- permitir recuperación parcial;
- permitir secuelas;
- permitir cicatrices cuando sean relevantes;
- permitir discapacidades permanentes cuando el diseño lo contemple;
- modificar temporalmente atributos;
- modificar temporalmente habilidades;
- modificar capacidad de movimiento;
- modificar capacidad de trabajo;
- modificar capacidad de combate;
- modificar capacidad de viaje;
- modificar comportamiento de NPC;
- permitir que un NPC evite actividades incompatibles con su estado fisico;
- permitir que NPC busquen ayuda;
- permitir que NPC soliciten tratamiento;
- permitir que NPC descansen;
- permitir que otros personajes auxilien a un herido;
- permitir transporte de personajes incapacitados cuando corresponda;
- gestionar muerte;
- distinguir distintas causas de muerte;
- registrar fecha de muerte;
- registrar lugar de muerte;
- registrar circunstancias de muerte cuando sean conocidas;
- permitir muertes instantáneas;
- permitir procesos de agonía cuando corresponda;
- impedir acciones de personajes fallecidos;
- mantener el personaje fallecido como entidad histórica;
- activar consecuencias sucesorias;
- activar consecuencias familiares;
- activar consecuencias sociales;
- activar consecuencias económicas;
- activar consecuencias políticas;
- permitir que una muerte desencadene investigaciones o acontecimientos;
- permitir cadáveres como entidades fisicas cuando sean relevantes;
- gestionar identificación de cadáveres cuando corresponda;
- permitir que una muerte sea desconocida para otros personajes;
- utilizar el Sistema de Conocimiento para controlar quién sabe que una persona está herida, enferma o muerta;
- permitir diagnósticos incorrectos;
- permitir enfermedades desconocidas para determinados personajes;
- permitir información médica incompleta;
- permitir ocultar una enfermedad o lesión;
- gestionar contagio según reglas configurables;
- gestionar exposición;
- gestionar inmunidad cuando corresponda;
- gestionar resistencia cuando corresponda;
- gestionar recuperación inmunológica cuando el diseño lo requiera;
- permitir epidemias locales;
- permitir epidemias regionales;
- permitir propagación entre asentamientos;
- permitir que viajes propaguen enfermedades;
- permitir que clima y condiciones ambientales influyan en determinadas enfermedades;
- permitir que alimentación y disponibilidad de recursos influyan en la salud cuando corresponda;
- permitir que condiciones laborales influyan en lesiones y enfermedades;
- permitir accidentes durante trabajos;
- permitir accidentes durante viajes;
- permitir accidentes durante procesos productivos;
- integrarse con combate;
- integrarse con profesiones;
- integrarse con objetos e inventario;
- integrarse con economía;
- integrarse con localizaciones;
- integrarse con clima;
- integrarse con crimen y justicia;
- integrarse con generaciones y legado;
- permitir profesiones sanitarias o equivalentes definidas por cada universo;
- permitir establecimientos de tratamiento;
- permitir costes económicos asociados a tratamientos;
- permitir disponibilidad limitada de medicamentos;
- permitir falta de profesionales;
- permitir diferencias regionales en conocimientos médicos;
- permitir tratamientos específicos de determinadas culturas;
- mantener separado el sistema técnico de las reglas médicas concretas de cada universo;
- permitir definir nuevas enfermedades mediante datos;
- permitir definir nuevas lesiones mediante datos;
- permitir definir nuevos tratamientos mediante datos;
- permitir definir nuevos estados fisicos sin modificar el núcleo;
- permitir distintos niveles de simulación según importancia del personaje;
- mantener simulación detallada para personajes relevantes;
- permitir simulación simplificada para población lejana;
- evitar actualizaciones constantes innecesarias en personajes no relevantes;
- mantener coherencia entre simulación detallada y simplificada;
- permitir que Norgard disponga inicialmente de sus enfermedades, tratamientos y conocimientos propios;
- permitir añadir posteriormente enfermedades, sustancias, tratamientos y prácticas propias de otros territorios humanos y territorios élficos;
- permitir que diferentes razas tengan reglas biológicas distintas mediante configuración;
- evitar codificar directamente reglas biológicas específicas de Nimroel dentro del RPG Core;
- proporcionar al Director información sobre muertes, epidemias, lesiones graves y situaciones sanitarias relevantes;
- permitir que Magíster utilice el estado fisico de personajes y poblaciones como contexto narrativo sin modificar directamente su estado real;
- conservar lesiones, enfermedades, tratamientos, secuelas y causas de muerte mediante guardado y carga.
## Depende de

- Núcleo de Partida
- Sistema de Estado del Mundo
- Sistema de Tiempo
- Sistema de Entidades e Identidad
- Sistema de Personajes
- Sistema de Atributos, Habilidades, Competencias, Aprendizaje y Progresión
- Sistema de Objetos, Inventario y Equipamiento
- Sistema de Datos, Configuración y Content Packs
- Sistema de Simulación, Planificación de Actualizaciones y Nivel de Detalle Lógico
- Sistema de Aleatoriedad, Semillas y Generación Procedural
- Sistema de Acciones, Reglas, Condiciones, Efectos y Validación de Gameplay
## Lo utilizan

- Sistema de Personaje Jugador, Creación de Personaje y Nueva Partida
- Sistema de NPC
- Sistema de Personajes
- Combat
- Professions
- Sistema de Viaje, Desplazamiento y Rutas
- Generations
- Crime System
- Sistema de Justicia, Leyes y Jurisdicciones
- Knowledge System
- Economy
- Organizations
- Events
- Quests
- Director
- Sistema de Historia y Crónica del Mundo
- Partida Maestra/Magíster
## Reutilización

RPG Core configurable. La infraestructura destinada a gestionar salud, daño, heridas, enfermedades, intoxicaciones, recuperación, tratamientos, secuelas y muerte deberá ser reutilizable. Las enfermedades concretas, anatomías, resistencias raciales, tratamientos, sustancias, conocimientos médicos, tasas de recuperación y demás reglas biológicas propias de Nimroel deberán definirse externamente mediante datos y configuración del universo. El sistema deberá permitir ampliar progresivamente su contenido por regiones y culturas, de forma que Norgard pueda contener inicialmente su conjunto sanitario y futuras regiones incorporen enfermedades, tratamientos o particularidades propias sin modificar la arquitectura del RPG Core.

## Documentación técnica

Obligatoria. Codex deberá crear y mantener la documentación técnica del sistema a medida que lo implemente y modifique. La documentación deberá reflejar exclusivamente la implementación real existente en el repositorio e incluir, como mínimo:

- arquitectura;
- clases y componentes;
- archivos;
- estructuras y enums;
- API pública;
- flujo de datos;
- inicialización;
- dependencias;
- comunicación con otros sistemas;
- persistencia;
- decisiones técnicas relevantes;
- diferencias entre Windows y Android cuando existan;
- pruebas y validaciones;
- limitaciones conocidas;
- elementos pertenecientes al RPG Core reutilizable;
- dependencias específicas de Nimroel;
- instrucciones necesarias para portar o reutilizar el sistema en otro videojuego. La documentación deberá mantenerse actualizada y versionada junto con el código.
## Estado

Pendiente
