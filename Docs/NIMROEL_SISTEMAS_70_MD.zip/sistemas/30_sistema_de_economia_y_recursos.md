# 30 · SISTEMA DE ECONOMÍA Y RECURSOS

## Qué es

Gestiona la capa económica y financiera del mundo: dinero, riqueza, cuentas, ingresos, gastos, deudas, obligaciones, impuestos, valoraciones e indicadores económicos. No crea ni transforma fisicamente recursos y bienes ni es propietario de los mercados o inventarios. Debe permitir que la situación económica de cada región, asentamiento, personaje u organización evolucione de forma persistente utilizando información procedente de Producción, Comercio, Inventario, Agricultura, Extracción, Ecología, Propiedad y demás sistemas. Producción será propietaria de las transformaciones input→output; Comercio de mercados, ofertas, demanda y transacciones; Inventario del stock fisico; Agricultura de cultivos y ganado; Extracción de la explotación de recursos; y Ecología de poblaciones y regeneración naturales.

## Debe permitir

- definir recursos económicos;
- definir bienes consumibles;
- definir materias primas;
- definir productos elaborados;
- definir bienes de lujo;
- definir bienes estratégicos;
- definir monedas;
- permitir varias monedas si el universo lo requiere;
- gestionar riqueza de personajes;
- gestionar riqueza de familias;
- gestionar riqueza de organizaciones;
- gestionar riqueza de asentamientos o instituciones cuando corresponda;
- registrar ingresos;
- registrar gastos;
- registrar pagos;
- registrar cobros;
- registrar transferencias económicas;
- proporcionar modelos de valoración económica y consumir los precios de mercado determinados por el Sistema de Comercio y Mercados;
- permitir valoraciones variables y utilizar precios de mercado variables proporcionados por Comercio;
- permitir que el Sistema de Comercio calcule precios de mercado según oferta, demanda y sus propias reglas, aportando la Economía los factores monetarios o macroeconómicos necesarios;
- representar y analizar diferencias económicas entre precios regionales proporcionados por los mercados;
- representar y analizar diferencias entre precios de establecimientos proporcionados por el Sistema de Comercio;
- permitir indicadores económicos de escasez derivados de disponibilidad, producción, inventarios y mercados;
- permitir indicadores económicos de excedente derivados de los sistemas propietarios correspondientes;
- permitir inflación o pérdida de valor cuando el diseño económico lo contemple;
- permitir cambios en el valor de una moneda;
- consultar la disponibilidad de bienes mantenida por Inventario, Producción, Comercio y otros sistemas propietarios;
- consultar y valorar reservas fisicas mantenidas por sus sistemas propietarios;
- consultar almacenes e instalaciones sin asumir la propiedad de su contenido fisico;
- consumir información de existencias proporcionada por Inventario y Comercio;
- registrar y agregar los efectos económicos del consumo resuelto por los sistemas propietarios;
- registrar y agregar los efectos económicos de la producción resuelta por el Sistema de Producción, Artesanía y Transformación, Agricultura, Extracción u otros propietarios;
- utilizar resultados económicos de transformaciones realizadas por el Sistema de Producción, Artesanía y Transformación;
- conservar referencias económicas a origen y destino cuando sean relevantes, dejando el movimiento fisico y las transacciones en Comercio, Viaje e Inventario;
- permitir analizar económicamente cadenas de producción definidas y ejecutadas por el Sistema de Producción;
- permitir representar dependencias económicas entre recursos sin convertirse en propietario de su creación o transformación;
- permitir que la producción local reportada por los sistemas propietarios afecte a riqueza, valoraciones e indicadores económicos;
- permitir que la producción regional reportada por los sistemas propietarios afecte a la economía agregada;
- permitir valorar y contabilizar producción atribuida a organizaciones sin ejecutar el proceso productivo;
- permitir contabilizar económicamente producción realizada por personajes o profesiones sin duplicar la lógica productiva;
- permitir pérdida de producción por guerra;
- permitir pérdida de producción por clima;
- permitir pérdida de producción por destrucción;
- reflejar económicamente pérdidas producidas por robos resueltos por Crimen, Inventario, Propiedad u otros sistemas correspondientes;
- reflejar económicamente confiscaciones ejecutadas por Justicia, Propiedad e Inventario cuando corresponda;
- permitir acumulación de riqueza;
- permitir pobreza;
- permitir desigualdad económica;
- influir en posición social;
- influir en relaciones;
- influir en decisiones de NPC;
- permitir necesidades económicas personales;
- permitir gastos cotidianos cuando el nivel de simulación lo requiera;
- evitar simular cada transacción menor cuando no aporte valor;
- permitir distintos niveles de abstracción económica;
- permitir economía detallada en áreas relevantes;
- permitir economía agregada en regiones lejanas;
- mantener coherencia entre simulación detallada y agregada;
- permitir salarios;
- permitir pagos por trabajos;
- permitir recompensas;
- permitir multas;
- permitir impuestos;
- permitir tasas;
- permitir tributos;
- permitir rentas;
- permitir alquileres;
- permitir deudas;
- permitir préstamos;
- permitir intereses si el sistema económico del universo lo contempla;
- permitir impagos;
- permitir embargos;
- permitir quiebras cuando proceda;
- permitir donaciones;
- permitir sobornos;
- permitir extorsiones;
- permitir economía criminal;
- permitir mercados legales e ilegales;
- permitir bienes prohibidos;
- permitir contrabando;
- permitir economía asociada a guerras;
- permitir financiación de organizaciones;
- permitir financiación de ejércitos;
- permitir costes de mantenimiento;
- permitir que organizaciones pierdan capacidad operativa por falta de recursos;
- permitir acumulación y agotamiento de reservas;
- gestionar recursos estratégicos de territorios;
- vincular recursos con localizaciones;
- vincular recursos con propiedades;
- permitir control económico de zonas;
- permitir disputas por recursos;
- permitir monopolios cuando surjan de forma natural o por reglas del mundo;
- permitir bloqueos económicos;
- permitir sanciones o restricciones comerciales cuando proceda;
- permitir crisis económicas locales o regionales;
- permitir recuperación económica;
- reaccionar ante crecimiento o descenso de población;
- reaccionar ante migraciones;
- reaccionar ante guerras;
- reaccionar ante cambios políticos;
- reaccionar ante cambios territoriales;
- reaccionar ante eventos climáticos;
- reaccionar ante catástrofes;
- reaccionar ante apertura o cierre de rutas;
- integrarse con comercio;
- integrarse con profesiones;
- integrarse con propiedad;
- integrarse con organizaciones;
- integrarse con producción;
- integrarse con agricultura;
- integrarse con minería u otros sistemas de extracción cuando existan;
- integrarse con crimen y justicia;
- integrarse con política;
- integrarse con guerra;
- proporcionar información económica al sistema de NPC;
- permitir que NPC tomen decisiones económicas en función de sus recursos, necesidades y conocimiento;
- impedir que NPC utilicen información económica que no conozcan;
- permitir información económica incompleta o incorrecta mediante el Sistema de Conocimiento;
- mantener historial de cambios económicos importantes;
- registrar crisis, escasez, colapsos o periodos de prosperidad relevantes;
- proporcionar al Director indicadores económicos utilizables para acontecimientos;
- permitir que Magíster utilice el estado económico como contexto narrativo sin modificar directamente la economía real;
- conservar todo el estado económico mediante guardado y carga.
## Depende de

- Núcleo de Partida
- Sistema de Estado del Mundo
- Sistema de Tiempo
- Sistema de Entidades e Identidad
- Sistema de Personajes
- Sistema de NPC
- Sistema de Conocimiento
- Sistema de Organizaciones y Facciones
- Sistema de Localizaciones y Estructura del Mundo
- Sistema de Propiedad y Posesiones
## Lo utilizan

- Sistema de Personaje Jugador, Creación de Personaje y Nueva Partida
- Sistema de NPC
- Organizations
- Property System
- Trade System
- Professions
- Production System
- Agriculture
- Resource Extraction
- Politics
- Diplomacy
- Crime System
- Sistema de Justicia, Leyes y Jurisdicciones
- Reputation
- War System
- Events
- Quests
- Director
- Sistema de Historia y Crónica del Mundo
- Partida Maestra/Magíster
## Reutilización

RPG Core configurable. La infraestructura destinada a gestionar dinero, riqueza, cuentas, valoraciones, ingresos, gastos, deudas, obligaciones, impuestos, agregados e indicadores económicos deberá ser reutilizable. Producción, consumo fisico, stock, mercados, oferta, demanda, transacciones y explotación de recursos deberán permanecer en sus sistemas propietarios. Las monedas concretas, recursos, bienes, fórmulas económicas, niveles tecnológicos, sistemas fiscales, restricciones comerciales y demás reglas propias de Nimroel deberán definirse externamente mediante datos y configuración del universo.

## Documentación técnica

Obligatoria. Codex deberá crear y mantener la documentación técnica del sistema a medida que lo implemente y modifique. La documentación deberá reflejar exclusivamente la implementación real existente en el repositorio e incluir, como mínimo:

- arquitectura;
- clases y componentes;
- archivos;
- estructuras y enums;
- API pública;
- flujo de datos;
- inicialización;
- dependencias;
- comunicación con otros sistemas;
- persistencia;
- decisiones técnicas relevantes;
- diferencias entre Windows y Android cuando existan;
- pruebas y validaciones;
- limitaciones conocidas;
- elementos pertenecientes al RPG Core reutilizable;
- dependencias específicas de Nimroel;
- instrucciones necesarias para portar o reutilizar el sistema en otro videojuego. La documentación deberá mantenerse actualizada y versionada junto con el código.
## Estado

Pendiente
