# 13 · SISTEMA DE INTERFAZ DE USUARIO (UI/UX)

## Qué es

Gestiona toda la interfaz visible de Nimroel RPG y la forma en que el jugador recibe información, navega por los sistemas del juego y expresa intenciones o solicita acciones a los sistemas correspondientes. Debe ofrecer una experiencia coherente entre Windows y Android, adaptándose al tipo de entrada, tamaño de pantalla, densidad de información y contexto de juego.

## Debe permitir

- mostrar HUD y paneles contextuales;
- mostrar menús principales y secundarios;
- gestionar ventanas, pestañas y paneles superpuestos;
- adaptar disposición y tamaño de elementos a Windows y Android;
- disponer de variantes de interfaz para ratón/teclado y táctil;
- mantener legibilidad en distintas resoluciones;
- gestionar escalado de textos e iconos;
- mostrar información del personaje;
- mostrar inventario;
- mostrar mapa;
- mostrar misiones, eventos y objetivos;
- mostrar relaciones, reputación y organizaciones;
- mostrar economía, comercio y recursos;
- mostrar diálogos y decisiones;
- mostrar información de combate;
- mostrar notificaciones y avisos;
- mostrar tooltips en Windows;
- ofrecer alternativas táctiles a cualquier información dependiente de hover;
- gestionar menús radiales o contextuales cuando sean útiles en Android;
- mantener jerarquía visual clara;
- impedir que la interfaz oculte información crítica;
- permitir cerrar, minimizar o cambiar paneles cuando corresponda;
- recordar preferencias de interfaz del jugador;
- permitir distintas densidades de información según plataforma;
- mantener consistencia visual entre todos los sistemas;
- permitir navegación accesible sin depender de precisión extrema del puntero;
- centralizar estilos, fuentes, iconografia, colores y componentes reutilizables;
- permitir actualizar el aspecto global sin rehacer cada pantalla;
- separar presentación de lógica de juego;
- recibir datos de los sistemas sin convertirse en fuente de verdad;
- mostrar información diferente según lo que realmente conoce el jugador;
- impedir que una interfaz destinada al jugador consulte directamente información omnisciente del World State; deberá utilizar datos player-safe proporcionados por los sistemas propietarios y por el Sistema de Conocimiento;
- preparar la interfaz para contenidos dinámicos generados por los sistemas del juego;
- permitir añadir nuevas pantallas y módulos sin romper la estructura existente.
## Depende de

- Núcleo de Partida
- Sistema de Plataforma, Dispositivo y Escalado
- Sistema de Entrada y Controles
- Sistema de Configuración, Accesibilidad y Preferencias del Usuario
## Lo utilizan

- Sistema de Personaje Jugador, Creación de Personaje y Nueva Partida
- Sistema de Personajes
- Inventory
- Maps
- Dialogs
- Combat
- Economy
- Organizations
- Knowledge System
- Crime System
- Quests
- Events
- Director
- Settngs
- Partida Maestra/Magíster
## Reutilización

RPG Core configurable. La infraestructura de ventanas, navegación, escalado, componentes reutilizables, adaptación táctil y comunicación entre interfaz y sistemas deberá formar parte del RPG Core. El aspecto visual, iconografia, terminología, pantallas específicas y contenido propio de Nimroel deberán mantenerse separados de dicha infraestructura.

## Documentación técnica

Obligatoria. Codex deberá crear y mantener la documentación técnica del sistema a medida que lo implemente y modifique. La documentación deberá reflejar exclusivamente la implementación real existente en el repositorio e incluir, como mínimo:

- arquitectura;
- clases y componentes;
- archivos;
- estructuras y enums;
- API pública;
- flujo de datos;
- inicialización;
- dependencias;
- comunicación con otros sistemas;
- persistencia;
- decisiones técnicas relevantes;
- diferencias entre Windows y Android cuando existan;
- pruebas y validaciones;
- limitaciones conocidas;
- elementos pertenecientes al RPG Core reutilizable;
- dependencias específicas de Nimroel;
- instrucciones necesarias para portar o reutilizar el sistema en otro videojuego. La documentación deberá mantenerse actualizada y versionada junto con el código.
## Estado

Pendiente
