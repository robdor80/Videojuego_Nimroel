# 19 · SISTEMA DE RELACIONES

## Qué es

Gestiona los vínculos entre personajes y cómo estos cambian a lo largo del tiempo según experiencias, decisiones, información conocida y acontecimientos compartidos. Debe permitir que las relaciones de Nimroel sean dinámicas, asimétricas y persistentes, evitando reducirlas a una única cifra genérica de “amistad”.

## Debe permitir

- crear relaciones entre personajes;
- mantener relaciones aunque uno de los personajes no esté cargado en escena;
- permitir relaciones asimétricas;
- gestionar amistad;
- gestionar confianza;
- gestionar respeto;
- gestionar afecto;
- gestionar atracción;
- gestionar miedo;
- gestionar odio;
- gestionar rivalidad;
- gestionar lealtad;
- gestionar dependencia;
- gestionar deuda personal;
- gestionar relaciones familiares;
- gestionar relaciones profesionales;
- gestionar relaciones políticas;
- registrar acontecimientos que hayan afectado a una relación;
- modificar relaciones por acciones directas del jugador;
- modificar relaciones por acciones entre NPC;
- modificar relaciones por rumores o información recibida;
- reaccionar de forma diferente según personalidad;
- permitir contradicciones emocionales;
- permitir relaciones ocultas;
- permitir relaciones públicas y privadas diferentes;
- gestionar amistad y enemistad entre miembros de organizaciones;
- permitir alianzas personales que contradigan intereses institucionales;
- permitir traiciones;
- permitir reconciliaciones;
- permitir ruptura de vínculos;
- permitir enamoramiento y formación de parejas;
- permitir matrimonio, separación o viudedad;
- influir en decisiones de NPC;
- influir en diálogos;
- influir en comercio y negociación;
- influir en cooperación y ayuda;
- influir en combate;
- influir en transmisión de información;
- influir en denuncias, acusaciones o encubrimientos;
- mantener memoria histórica de relaciones importantes;
- permitir que una relación continúe teniendo consecuencias tras la muerte de uno de los implicados;
- integrarse con generaciones, familias y linajes;
- permitir consultas del tipo “quién confia en quién”, “quién odia a quién” o “quién debe favores a quién”;
- proporcionar datos al Director y a Magíster sin permitir que estos alteren arbitrariamente la verdad del mundo.
## Depende de

- Núcleo de Partida
- Sistema de Estado del Mundo
- Sistema de Tiempo
- Sistema de Entidades e Identidad
- Sistema de Personajes
## Lo utilizan

- Sistema de NPC
- Knowledge System
- Generations
- Organizations
- Crime System
- Economy
- Dialogues
- Reputation
- Combat
- Events
- Quests
- Director
- Partida Maestra/Magíster
## Reutilización

RPG Core configurable. La infraestructura para crear, modificar, consultar y mantener relaciones entre entidades deberá ser reutilizable. Los tipos concretos de relación, reglas sociales, matrimoniales, familiares, culturales o políticas particulares de Nimroel deberán definirse mediante configuración y no quedar incorporados rígidamente al núcleo.

## Documentación técnica

Obligatoria. Codex deberá crear y mantener la documentación técnica del sistema a medida que lo implemente y modifique. La documentación deberá reflejar exclusivamente la implementación real existente en el repositorio e incluir, como mínimo:

- arquitectura;
- clases y componentes;
- archivos;
- estructuras y enums;
- API pública;
- flujo de datos;
- inicialización;
- dependencias;
- comunicación con otros sistemas;
- persistencia;
- decisiones técnicas relevantes;
- diferencias entre Windows y Android cuando existan;
- pruebas y validaciones;
- limitaciones conocidas;
- elementos pertenecientes al RPG Core reutilizable;
- dependencias específicas de Nimroel;
- instrucciones necesarias para portar o reutilizar el sistema en otro videojuego. La documentación deberá mantenerse actualizada y versionada junto con el código.
## Estado

Pendiente
