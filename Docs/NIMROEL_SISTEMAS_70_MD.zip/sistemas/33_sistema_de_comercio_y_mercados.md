# 33 · SISTEMA DE COMERCIO Y MERCADOS

## Qué es

Gestiona el intercambio de bienes, recursos y servicios entre personajes, organizaciones, establecimientos, asentamientos y regiones. Debe permitir que el comercio responda al estado real de la economía, a la disponibilidad de rutas, a la información conocida por los participantes y a las condiciones políticas, sociales, climáticas o militares del mundo.

## Debe permitir

- crear mercados locales;
- crear mercados regionales;
- crear establecimientos comerciales;
- crear comerciantes individuales;
- crear comerciantes vinculados a organizaciones;
- gestionar compradores;
- gestionar vendedores;
- gestionar ofertas;
- gestionar demandas;
- gestionar existencias disponibles para venta;
- gestionar precios de compra;
- gestionar precios de venta;
- calcular márgenes comerciales;
- permitir precios distintos entre comerciantes;
- permitir precios distintos entre asentamientos;
- permitir precios distintos entre regiones;
- modificar precios según oferta y demanda;
- modificar precios según disponibilidad;
- modificar precios según escasez;
- modificar precios según abundancia;
- modificar precios según acontecimientos;
- modificar precios según relaciones personales;
- modificar precios según reputación;
- modificar precios según pertenencia a organizaciones;
- permitir negociación;
- permitir regateo cuando corresponda;
- permitir descuentos;
- permitir sobreprecios;
- permitir favores comerciales;
- permitir intercambios sin moneda;
- permitir trueque;
- permitir pagos mixtos;
- permitir compra de bienes;
- permitir venta de bienes;
- permitir compra de recursos;
- permitir venta de recursos;
- permitir contratación de servicios;
- permitir encargos;
- permitir pedidos;
- permitir reservas de productos;
- permitir contratos comerciales;
- permitir entregas futuras;
- permitir incumplimientos;
- permitir penalizaciones comerciales cuando proceda;
- gestionar rutas comerciales;
- relacionar mercados mediante rutas;
- calcular costes asociados al transporte;
- tener en cuenta distancia entre mercados;
- tener en cuenta duración del viaje;
- tener en cuenta peligros de las rutas;
- tener en cuenta clima;
- tener en cuenta guerras;
- tener en cuenta bloqueos;
- tener en cuenta fronteras;
- tener en cuenta restricciones políticas;
- permitir interrupción temporal de rutas;
- permitir apertura de nuevas rutas;
- permitir desaparición de rutas;
- permitir rutas alternativas;
- permitir comercio terrestre;
- permitir otras formas de transporte cuando el universo las contemple;
- gestionar caravanas u otros grupos de transporte cuando sea necesario;
- gestionar mercancías en tránsito;
- permitir pérdida de mercancías;
- permitir robo de mercancías;
- permitir destrucción de cargamentos;
- permitir retrasos;
- permitir confiscaciones;
- permitir tasas de paso;
- permitir peajes;
- permitir aranceles;
- permitir impuestos comerciales;
- permitir prohibiciones de importación o exportación;
- permitir bienes restringidos;
- permitir bienes ilegales;
- permitir contrabando;
- permitir mercados negros;
- permitir comercio clandestino;
- permitir que organizaciones controlen mercados;
- permitir monopolios;
- permitir competencia entre comerciantes;
- permitir competencia entre organizaciones;
- permitir acuerdos comerciales;
- permitir embargos;
- permitir sanciones económicas;
- permitir bloqueos comerciales;
- permitir apertura comercial entre territorios;
- influir en disponibilidad regional de bienes;
- influir en precios regionales;
- influir en riqueza de comerciantes;
- influir en riqueza de organizaciones;
- influir en riqueza de asentamientos;
- influir en producción;
- influir en profesiones;
- influir en decisiones de NPC;
- permitir que NPC detecten oportunidades comerciales;
- permitir que NPC compren bienes según sus necesidades;
- permitir que NPC vendan excedentes;
- permitir que comerciantes adapten sus decisiones al beneficio esperado;
- impedir que comerciantes conozcan automáticamente precios o existencias de otros mercados;
- utilizar el Sistema de Conocimiento para representar información comercial;
- permitir información sobre precios desactualizada;
- permitir rumores sobre escasez o abundancia;
- permitir información comercial falsa;
- permitir espionaje económico;
- permitir intermediarios;
- registrar transacciones importantes;
- registrar origen y destino de mercancías cuando sea relevante;
- mantener historial de precios cuando sea necesario;
- detectar cambios económicos significativos;
- permitir crisis comerciales;
- permitir recuperación de mercados;
- reaccionar ante cambios de población;
- reaccionar ante cambios de producción;
- reaccionar ante cambios de recursos;
- reaccionar ante guerras;
- reaccionar ante decisiones políticas;
- reaccionar ante cambios diplomáticos;
- reaccionar ante clima extremo;
- reaccionar ante catástrofes;
- reaccionar ante crimen organizado;
- integrarse con propiedad;
- integrarse con economía;
- integrarse con organizaciones;
- integrarse con localizaciones;
- integrarse con profesiones;
- integrarse con producción;
- integrarse con transporte y viaje;
- integrarse con crimen y justicia;
- integrarse con política;
- integrarse con diplomacia;
- integrarse con guerra;
- permitir comercio entre regiones futuras sin modificar la arquitectura base;
- permitir incorporar nuevas regiones de Nimroel mediante configuración;
- permitir que Norgard funcione inicialmente como única región jugable sin asumir que será la única región del mundo;
- permitir que futuras regiones humanas y élficas se incorporen al sistema comercial sin rehacerlo;
- permitir comercio simulado con regiones todavía no accesibles al jugador cuando el diseño lo contemple;
- permitir distintos niveles de simulación según la importancia del mercado;
- evitar simular individualmente cada transacción irrelevante;
- utilizar simulación agregada cuando corresponda;
- proporcionar al Director información sobre escasez, rutas, crisis y oportunidades comerciales;
- permitir que Magíster utilice el estado del comercio como contexto narrativo sin modificar directamente la economía real;
- conservar todo el estado comercial mediante guardado y carga.
## Depende de

- Núcleo de Partida
- Sistema de Estado del Mundo
- Sistema de Tiempo
- Sistema de Entidades e Identidad
- Sistema de Personajes
- Sistema de NPC
- Sistema de Relaciones
- Sistema de Conocimiento
- Sistema de Organizaciones y Facciones
- Sistema de Localizaciones y Estructura del Mundo
- Sistema de Propiedad y Posesiones
- Sistema de Economía y Recursos
## Lo utilizan

- Sistema de Personaje Jugador, Creación de Personaje y Nueva Partida
- Sistema de NPC
- Organizations
- Economy
- Professions
- Production System
- Transport System
- Sistema de Viaje, Desplazamiento y Rutas
- Crime System
- Sistema de Justicia, Leyes y Jurisdicciones
- Politics
- Diplomacy
- Reputation
- War System
- Events
- Quests
- Director
- Sistema de Historia y Crónica del Mundo
- Partida Maestra/Magíster
## Reutilización

RPG Core configurable. La infraestructura destinada a gestionar mercados, transacciones, precios, rutas comerciales, comerciantes, negociación, transporte de mercancías, restricciones y evolución del comercio deberá ser reutilizable. Las monedas, bienes, recursos, tipos de mercado, reglas comerciales, impuestos, aranceles, rutas, restricciones culturales y demás particularidades propias de Nimroel deberán definirse externamente mediante datos y configuración del universo.

El sistema deberá permitir incorporar nuevas regiones y mercados sin modificar su arquitectura, de forma que el lanzamiento inicial limitado a Norgard no condicione la posterior incorporación de otros territorios humanos, territorios élficos u otras regiones del mundo.

## Documentación técnica

Obligatoria. Codex deberá crear y mantener la documentación técnica del sistema a medida que lo implemente y modifique. La documentación deberá reflejar exclusivamente la implementación real existente en el repositorio e incluir, como mínimo:

- arquitectura;
- clases y componentes;
- archivos;
- estructuras y enums;
- API pública;
- flujo de datos;
- inicialización;
- dependencias;
- comunicación con otros sistemas;
- persistencia;
- decisiones técnicas relevantes;
- diferencias entre Windows y Android cuando existan;
- pruebas y validaciones;
- limitaciones conocidas;
- elementos pertenecientes al RPG Core reutilizable;
- dependencias específicas de Nimroel;
- instrucciones necesarias para portar o reutilizar el sistema en otro videojuego. La documentación deberá mantenerse actualizada y versionada junto con el código.
## Estado

Pendiente
