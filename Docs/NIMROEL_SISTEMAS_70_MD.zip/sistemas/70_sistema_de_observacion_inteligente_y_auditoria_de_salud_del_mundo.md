# 70 · SISTEMA DE OBSERVACIÓN INTELIGENTE Y AUDITORÍA DE SALUD DEL MUNDO

## Qué es

Es la infraestructura encargada de construir una lectura inteligente, incremental y no autoritativa de la evolución global del mundo, auditar periódicamente que la simulación continúa comportándose de forma coherente y preparar un diagnóstico exhaustivo cuando existan indicios de un fallo técnico real.

Debe permitir que un mundo de gran tamaño pueda seguir siendo observado aunque la mayor parte de sus procesos ocurran lejos del jugador, conectando señales procedentes de sistemas diferentes sin sustituir a dichos sistemas ni convertir una IA generativa en fuente de verdad.

El sistema deberá separar estrictamente tres conceptos:

- **hechos del mundo**, producidos y consolidados exclusivamente por los sistemas propietarios y el World State;
- **inteligencia del mundo**, formada por resúmenes, patrones, hipótesis, tendencias y relaciones inferidas a partir de hechos existentes;
- **salud técnica del mundo**, entendida como la evaluación de si la simulación respeta reglas, invariantes, causalidad, contratos, límites técnicos y comportamiento esperado del motor.

Una situación extraordinaria no deberá considerarse una anomalía por ser extraordinaria. Una conspiración, un golpe de Estado, una guerra civil, una epidemia, una Casa que acumula un poder enorme, una ciudad que entra en decadencia o una dinastía que desaparece podrán ser resultados emergentes completamente válidos si proceden de la simulación y respetan las reglas del mundo.

El sistema no deberá proteger al mundo de sus propias consecuencias legítimas. Deberá detectar cuándo algo se ha salido de los límites de la maquinaria que lo produce, no cuándo la historia ha tomado un rumbo incómodo, sorprendente o dramático.

Conceptualmente deberá permitir un flujo semejante a:

`Sistemas del mundo → eventos y cambios → filtrado local → acumulación/batching → World Observer → World Intelligence State → World Auditor → clasificación de salud → si existe anomalía técnica: Diagnostic Package → revisión externa → Repair Proposal → validación local → dry-run → backup → aplicación autorizada → verificación/rollback`.

La posible utilización de modelos concretos deberá permanecer desacoplada mediante el Sistema de Enrutado y Selección de Modelos de IA. Los nombres comerciales utilizados durante el desarrollo serán perfiles de referencia sustituibles, no dependencias del RPG Core.

## Debe permitir

### A. Principios de autoridad y separación de responsabilidades

- mantener al World State y a los sistemas propietarios como únicas autoridades sobre los hechos objetivos del mundo;
- impedir que el World Observer cree por sí mismo acontecimientos, relaciones, propiedades, muertes, guerras, decisiones NPC, movimientos económicos o cualquier otro hecho autoritativo;
- impedir que el World Auditor modifique directamente el World State;
- impedir que una revisión externa modifique directamente el World State;
- tratar todas las salidas generativas como interpretación, hipótesis, diagnóstico o propuesta hasta que el sistema correspondiente las valide;
- distinguir hechos de inferencias;
- distinguir inferencias de hipótesis;
- distinguir hipótesis de recomendaciones;
- distinguir anomalía técnica de resultado emergente legítimo;
- distinguir problema de balance de corrupción o fallo lógico;
- distinguir rareza estadística de imposibilidad;
- distinguir situación negativa para el jugador de error de simulación;
- distinguir desviación respecto de una planificación narrativa de violación de reglas del mundo;
- permitir que la historia de una partida se aleje radicalmente de expectativas iniciales sin ser corregida por ello;
- respetar hechos consolidados;
- respetar causalidad;
- respetar invariantes de los sistemas propietarios;
- respetar el aislamiento absoluto entre saves;
- impedir que una observación perteneciente a una partida contamine otra;
- impedir que un diagnóstico perteneciente a una partida se aplique a otra;
- mantener trazabilidad entre observaciones, hechos fuente, auditorías y cualquier reparación posterior.

### B. World Observer — observación inteligente casi continua

- proporcionar una capacidad lógica denominada `WORLD_OBSERVER` o equivalente;
- permitir ejecutarla mediante cualquier modelo compatible autorizado por el Router;
- permitir como perfil inicial de referencia un modelo ligero y económico o gratuito, actualmente previsto durante desarrollo como Gemini Flash-Lite 3.5, sin convertir ese nombre en dependencia permanente;
- recibir cambios estructurados producidos por los sistemas del mundo;
- recibir eventos consolidados;
- recibir cambios de relaciones;
- recibir cambios políticos;
- recibir cambios diplomáticos;
- recibir cambios militares;
- recibir cambios económicos;
- recibir cambios comerciales;
- recibir cambios criminales y judiciales;
- recibir cambios demográficos;
- recibir cambios familiares y generacionales;
- recibir movimientos migratorios;
- recibir cambios de propiedad;
- recibir cambios de organizaciones;
- recibir cambios sanitarios;
- recibir cambios ambientales y climáticos cuando sean relevantes;
- recibir cambios de producción, abastecimiento y recursos;
- recibir cambios de reputación, estatus y movilidad social;
- recibir acontecimientos y consecuencias producidos por cualquier sistema futuro mediante contratos extensibles;
- evitar escanear de forma ingenua todo el World State en cada ciclo;
- utilizar eventos, deltas, índices, suscripciones y consultas dirigidas;
- permitir procesamiento local previo;
- permitir filtrado local previo;
- permitir selección local de cambios significativos;
- permitir agregación de cambios menores;
- permitir batching;
- permitir ventanas temporales configurables;
- permitir ventanas por región;
- permitir ventanas por entidad;
- permitir ventanas por organización;
- permitir ventanas por hilo emergente cuando exista;
- permitir frecuencia adaptativa;
- permitir observación aproximadamente cada cierto número de segundos o minutos reales cuando actividad, cuota y presupuesto lo permitan;
- impedir que una frecuencia configurada obligue a realizar una llamada si no existe información relevante nueva;
- permitir cero llamadas durante periodos sin cambios significativos;
- permitir adelantar una observación cuando se acumule suficiente actividad relevante;
- permitir retrasarla cuando la cuota o presupuesto se aproximen a un límite;
- permitir combinar cientos de cambios menores en una representación compacta;
- impedir enviar información irrelevante únicamente porque esté disponible;
- priorizar cambios por novedad, magnitud, importancia sistémica, causalidad, relación con procesos activos, sorpresa y riesgo técnico;
- permitir que la importancia para el Observer sea independiente de la cercanía al jugador;
- permitir detectar situaciones importantes en Hallheim aunque el jugador se encuentre en Treskal o en una aldea remota de Norgard;
- permitir observar procesos que jamás lleguen a cruzarse con el jugador;
- evitar convertir la atención del jugador en medida única de importancia mundial;
- mantener un resumen incremental de la situación mundial;
- utilizar el resumen anterior más los deltas nuevos cuando sea seguro;
- poder reconstruir el contexto necesario desde datos del juego sin depender de memoria permanente del proveedor;
- persistir únicamente el estado derivado necesario cuando compense hacerlo;
- permitir invalidar resúmenes derivados cuando cambien sus hechos base;
- mantener identificadores de eventos y entidades utilizados como evidencia;
- registrar revisión de World State utilizada;
- registrar ventana temporal analizada;
- registrar proveedor y modelo utilizados internamente para diagnóstico técnico;
- permitir regenerar una observación;
- permitir comparar dos observaciones;
- permitir pruebas con modelos diferentes sobre el mismo lote de hechos.

### C. World Intelligence State

- mantener una representación estructurada y no autoritativa denominada `World Intelligence State` o equivalente;
- resumir situaciones globales relevantes;
- mantener situaciones regionales;
- mantener tendencias;
- mantener procesos emergentes;
- mantener actores relevantes dentro de cada proceso;
- mantener relaciones entre procesos cuando existan evidencias suficientes;
- mantener hipótesis de conexión entre hechos de sistemas distintos;
- mantener nivel de confianza orientativo;
- mantener hechos que apoyan una hipótesis;
- mantener hechos que la contradicen;
- mantener evolución temporal de una hipótesis;
- permitir que una hipótesis aumente o disminuya de relevancia;
- permitir que una hipótesis desaparezca sin producir efecto alguno sobre el mundo;
- permitir que dos hipótesis compitan;
- impedir que una hipótesis se convierta en verdad porque se repita en varios resúmenes;
- impedir que el modelo invente entidades para completar una explicación;
- validar todas las referencias;
- permitir detectar patrones que ningún sistema aislado vea por sí solo;
- permitir relacionar, por ejemplo, compras de armas, movimientos de dinero, cambios de guardia, cambios de lealtad, contratación de mercenarios y desaparición de un funcionario como señales posiblemente conectadas;
- permitir también concluir que dichos hechos no forman un proceso común;
- permitir representar incertidumbre;
- permitir solicitar contexto adicional cuando no exista evidencia suficiente;
- evitar realizar retrieval indiscriminado;
- permitir retrieval por entidad, periodo, región, evento, organización o dominio;
- permitir que el Director consuma esta capa como ayuda de priorización;
- permitir que Magíster la utilice como resumen auxiliar dentro de sus permisos;
- impedir que NPC o jugador accedan automáticamente a esta representación omnisciente;
- impedir que el `World Intelligence State` sea utilizado como sustituto del Sistema de Conocimiento.

### D. Detección de patrones emergentes

- buscar correlaciones entre dominios diferentes cuando exista fundamento en los datos;
- detectar acumulaciones de tensión;
- detectar cambios bruscos de poder;
- detectar concentraciones de riqueza o propiedad;
- detectar deterioros sistémicos de relaciones;
- detectar proliferación anómala de una conducta;
- detectar cambios demográficos extremos;
- detectar ciclos económicos extraños;
- detectar conflictos que se retroalimentan;
- detectar organizaciones que están absorbiendo o perdiendo miembros de forma excepcional;
- detectar cadenas de decisiones que convergen sobre un mismo actor o región;
- detectar procesos de largo plazo difíciles de ver en eventos individuales;
- distinguir patrón narrativamente interesante de posible problema técnico;
- permitir que un patrón narrativamente interesante sea remitido al Director sin ser considerado problema;
- permitir que un patrón técnicamente sospechoso sea remitido al World Auditor;
- permitir que un mismo patrón sea simultáneamente interesante y técnicamente correcto;
- evitar corregir automáticamente outliers plausibles;
- permitir que sociedades, familias, mercados, guerras y organizaciones evolucionen hacia estados muy diferentes de los iniciales cuando sus causas sean válidas.

### E. World Auditor — auditoría periódica de salud

- proporcionar una capacidad lógica denominada `WORLD_AUDITOR` o equivalente;
- permitir ejecutarla mediante un modelo de capacidad superior al observador cuando resulte conveniente;
- permitir como perfil inicial de referencia un modelo como Gemini 3.8 durante desarrollo, sin convertirlo en dependencia permanente;
- recibir periódicamente una síntesis del `World Intelligence State`;
- recibir tendencias acumuladas;
- recibir indicadores técnicos;
- recibir muestras o resúmenes de hechos fuente relevantes;
- recibir invariantes y reglas aplicables cuando sean necesarias;
- recibir cambios desde la auditoría anterior;
- recibir historial de alertas previas;
- recibir información de versiones de sistemas y Content Packs cuando pueda ser relevante;
- analizar si la evolución aparente continúa siendo compatible con reglas, causalidad e invariantes;
- comprobar si existen patrones que sugieran multiplicadores duplicados;
- comprobar si existen procesos que crecen sin límites cuando deberían estabilizarse;
- comprobar si aparecen referencias inválidas;
- comprobar si aparecen propiedades sin propietario válido cuando el dominio lo prohíba;
- comprobar si aparecen estados familiares, políticos, económicos o demográficos imposibles;
- comprobar si varios sistemas parecen estar aplicando dos veces una misma consecuencia;
- comprobar si existe comportamiento que contradiga repetidamente las reglas de los NPC;
- comprobar si existe una divergencia masiva después de una versión concreta;
- comprobar si un sistema parece haberse detenido;
- comprobar si un sistema produce cantidades anormalmente grandes o pequeñas respecto de su propio historial;
- utilizar dichas señales como indicios y no como prueba suficiente por sí solas;
- poder solicitar evidencia adicional antes de clasificar una anomalía;
- poder recomendar aumentar temporalmente la observación sobre un dominio o conjunto de entidades;
- poder concluir expresamente que una situación extraordinaria es causalmente plausible y no requiere intervención;
- evitar confundir «no esperado por el diseñador» con «incorrecto»;
- evitar confundir «malo para el personaje jugador» con «malo para la simulación»;
- evitar confundir «históricamente raro» con «técnicamente imposible»;
- mantener independencia respecto del plan narrativo deseado;
- impedir que el auditor intente devolver el mundo a un estado narrativamente preferido.

### F. Clasificación de salud

- producir una clasificación estructurada de salud;
- permitir como mínimo `HEALTHY`;
- permitir `SUSPICIOUS_BUT_PLAUSIBLE`;
- permitir `TECHNICAL_ANOMALY`;
- permitir subtipos o severidades adicionales mediante configuración;
- considerar `HEALTHY` cualquier situación que, aun siendo dramática o extraordinaria, respete las reglas y la causalidad disponibles;
- permitir que `SUSPICIOUS_BUT_PLAUSIBLE` active observación adicional sin avisar al jugador/desarrollador con detalles narrativos sensibles;
- utilizar `TECHNICAL_ANOMALY` únicamente cuando exista evidencia suficiente de fallo técnico, corrupción, violación de invariantes, error de datos o comportamiento incompatible con la maquinaria prevista;
- incluir evidencia y grado de severidad;
- incluir sistemas posiblemente afectados;
- incluir periodo aproximado de inicio;
- incluir entidades o regiones relevantes;
- incluir qué información adicional se necesita para diagnóstico;
- permitir revisar o retirar una clasificación ante nueva evidencia;
- impedir que una clasificación cree automáticamente un parche.

### G. Firewall de spoilers y separación Roberto jugador / Roberto desarrollador

- mantener una frontera explícita entre información omnisciente de mantenimiento e información que puede recibir el jugador;
- considerar que el usuario puede ser simultáneamente jugador y desarrollador;
- impedir que una revisión de salud normal arruine la experiencia narrativa;
- cuando el resultado sea `HEALTHY`, proporcionar al usuario únicamente una conclusión técnica player-safe equivalente a «todo correcto; el mundo continúa dentro de parámetros normales; no se requiere intervención»;
- impedir que ese mensaje revele qué acontecimientos secretos fueron analizados;
- impedir que revele actores implicados;
- impedir que revele localizaciones de conspiraciones;
- impedir que revele guerras en preparación;
- impedir que revele asesinatos todavía desconocidos;
- impedir que revele relaciones secretas;
- impedir que revele traiciones;
- impedir que revele sucesiones todavía no conocidas por el personaje;
- impedir que revele cualquier otra información a la que el personaje jugador no tenga acceso;
- cuando el resultado sea `SUSPICIOUS_BUT_PLAUSIBLE`, mantener igualmente ocultos los detalles narrativos y continuar observando;
- permitir informar únicamente de que no existe todavía una anomalía confirmada que requiera intervención;
- cuando el resultado sea `TECHNICAL_ANOMALY`, cambiar explícitamente a contexto de desarrollo;
- permitir entonces revelar los datos internos necesarios para reparar el motor o la partida;
- limitar incluso en modo desarrollo la exposición a lo necesario cuando pueda diagnosticarse el problema sin revelar contenido irrelevante;
- mantener mensajes player-safe y developer-full separados en estructuras diferentes;
- impedir que una herramienta de UI mezcle accidentalmente ambos campos;
- permitir pruebas automáticas específicas contra filtraciones de spoilers.

### H. Mundo independiente del jugador

- reforzar el principio de que el jugador no es el centro temporal ni causal del universo;
- permitir que acontecimientos importantes ocurran lejos del jugador;
- permitir que problemas sean resueltos sin su intervención;
- permitir que otros problemas empeoren sin su intervención;
- permitir que reyes mueran;
- permitir sucesiones;
- permitir golpes de Estado;
- permitir guerras;
- permitir tratados;
- permitir nacimientos;
- permitir matrimonios;
- permitir separaciones;
- permitir migraciones;
- permitir ascenso y ruina de familias;
- permitir aparición y desaparición de organizaciones;
- permitir cambios económicos y sociales durante décadas;
- permitir que el personaje jugador se retire, forme familia, envejezca y muera sin congelar la historia general;
- permitir que un jugador asentado en una aldea remota reciba únicamente aquellas noticias que puedan llegar físicamente o socialmente hasta él;
- permitir que una noticia tarde días, meses o años en llegar;
- permitir que llegue deformada;
- permitir que llegue incompleta;
- permitir que diferentes NPC cuenten versiones diferentes;
- permitir que una noticia nunca llegue;
- mantener completamente separada la verdad objetiva conocida por los sistemas de la información disponible para el personaje;
- dejar en manos de Percepción, Comunicación, Conocimiento, Diálogo, Eventos y sistemas correspondientes la propagación de información;
- impedir telepatía sistémica entre `World Intelligence State` y el jugador.

### I. Generación del paquete forense

- activar la generación de un paquete de diagnóstico únicamente ante una anomalía técnica confirmada o ante una solicitud manual de desarrollo autorizada;
- permitir que el auditor produzca un `DiagnosticRequest` indicando evidencia necesaria;
- recopilar automáticamente la información relevante de los sistemas afectados;
- permitir recopilar World State relacionado;
- permitir recopilar eventos;
- permitir recopilar cadenas causales;
- permitir recopilar decisiones NPC;
- permitir recopilar relaciones;
- permitir recopilar transacciones;
- permitir recopilar cambios políticos;
- permitir recopilar cambios económicos;
- permitir recopilar cambios demográficos;
- permitir recopilar organizaciones;
- permitir recopilar datos de salud, combate, crimen u otros dominios cuando correspondan;
- permitir recopilar reglas e invariantes aplicables;
- permitir recopilar parámetros de configuración;
- permitir recopilar versiones de algoritmos;
- permitir recopilar versiones de Content Packs;
- permitir recopilar seeds y streams relevantes cuando sean necesarios para reproducibilidad;
- permitir recopilar trazas de RNG autorizadas;
- permitir recopilar historial del Observer;
- permitir recopilar auditorías anteriores;
- permitir recopilar alertas y cambios de clasificación;
- permitir recopilar logs técnicos relacionados;
- permitir recopilar información de modelo/proveedor utilizada únicamente para diagnóstico;
- permitir incluir el informe que originó la escalada;
- utilizar retrieval dirigido para no exportar todo el save cuando no sea necesario;
- permitir ampliar el paquete si la primera revisión determina que faltan datos;
- permitir, en casos excepcionales, un paquete muy grande cuando el diagnóstico lo requiera;
- generar un manifest;
- incluir versión de schema;
- incluir identificador único del save;
- incluir revisión objetivo;
- incluir fecha de mundo y fecha técnica;
- incluir lista de archivos;
- incluir hashes cuando resulte apropiado;
- incluir explicación de por qué se generó;
- incluir dominios sospechosos;
- incluir qué datos pueden contener spoilers;
- permitir compresión ZIP o formato equivalente adecuado;
- impedir incluir credenciales, API keys, tokens de autenticación u otros secretos técnicos;
- permitir anonimizar información externa que no sea necesaria;
- validar integridad antes de exportar;
- permitir reproducir la recopilación cuando el estado y logs necesarios continúen disponibles.

### J. Revisión externa de máxima capacidad

- permitir exportar el paquete para análisis manual mediante una IA externa de gran capacidad;
- mantener este flujo fuera del bucle de gameplay en tiempo real;
- permitir como perfil inicial de desarrollo ChatGPT Sol High utilizado externamente por el desarrollador;
- no requerir API para esta revisión;
- permitir que el desarrollador entregue manualmente el ZIP a la herramienta externa;
- permitir que la revisión externa analice un contexto mucho mayor que el razonablemente enviado en runtime;
- pedir a la revisión externa que determine primero si existe realmente un problema técnico;
- permitir que concluya que no existe ningún fallo y que la situación es comportamiento emergente válido;
- en ese caso, exigir una respuesta player-safe que no revele secretos narrativos al usuario-jugador;
- permitir que la revisión externa estudie causa raíz cuando exista fallo;
- permitir identificar cuándo comenzó;
- permitir identificar sistemas afectados;
- permitir identificar datos ya consolidados que deben preservarse;
- permitir distinguir reparación del motor de reparación de una partida concreta;
- permitir distinguir corrección de configuración de migración de datos;
- permitir recomendar no tocar el World State cuando corregir el código baste para el futuro;
- permitir proponer una migración cuando los datos persistidos ya estén dañados;
- impedir que la revisión externa tenga autoridad automática;
- tratar su respuesta como una propuesta estructurada.

### K. Repair Proposal e importación

- permitir que la herramienta externa genere un JSON de solución conforme a schema;
- denominarlo `RepairProposal` o equivalente;
- incluir diagnóstico;
- incluir causa raíz propuesta;
- incluir nivel de confianza;
- incluir sistemas afectados;
- incluir versión o revisión en la que se detectó;
- incluir operaciones técnicas sugeridas;
- incluir operaciones sobre datos únicamente cuando sean imprescindibles;
- incluir hechos que deben preservarse;
- incluir precondiciones;
- incluir comprobaciones posteriores;
- incluir estrategia de rollback;
- incluir posibles efectos secundarios;
- incluir instrucciones para rechazar el parche si alguna precondición falla;
- validar que todas las entidades referenciadas existan;
- validar que el save objetivo sea correcto;
- validar versión base;
- validar schema;
- validar permisos;
- validar reglas de gameplay;
- validar historia consolidada;
- impedir retcon automático para recuperar una narrativa anterior;
- impedir borrar una guerra legítima porque haya resultado inconveniente;
- impedir deshacer una muerte legítima únicamente porque complique la historia;
- impedir restaurar una dinastía perdida si su desaparición fue sistémicamente válida;
- permitir corregir datos que sean demostrablemente producto de un bug cuando exista un procedimiento autorizado;
- permitir generar backup antes de aplicar;
- permitir dry-run;
- permitir simulación de impacto;
- permitir mostrar diferencias previstas en herramientas de desarrollo;
- permitir aprobación explícita del desarrollador cuando la reparación sea estructural;
- aplicar cambios mediante los sistemas propietarios y Master Patch System cuando corresponda;
- impedir escrituras arbitrarias directas sobre World State;
- permitir aplicación transaccional;
- permitir rollback técnico;
- verificar invariantes después de aplicar;
- ejecutar una auditoría posterior;
- registrar resultado;
- conservar el paquete, diagnóstico y parche para trazabilidad cuando el desarrollador lo decida.

### L. Relación con Master Patch System

- utilizar Master Patch System cuando la reparación afecte planificación futura o estructuras para las que ya exista ese contrato;
- no duplicar la infraestructura de parches estructurales existente;
- distinguir un Master Patch narrativo de una reparación técnica;
- permitir que una reparación técnica desencadene posteriormente una replanificación si el mundo válido resultante lo requiere;
- impedir que una replanificación se utilice como excusa para borrar hechos legítimos;
- permitir que el mundo continúe desde la situación válida real una vez corregido el fallo.

### M. Disponibilidad, fallbacks y retirada de proveedores

- funcionar con varios proveedores;
- permitir cambiar de proveedor sin modificar los consumidores;
- permitir que Google, Mistral, OpenAI o cualquier proveedor futuro sea sustituido;
- permitir que un modelo sea retirado;
- permitir que cambie de nombre;
- permitir que cambie de precio;
- permitir que pierda su free tier;
- permitir que reduzca cuotas;
- permitir que deje de cumplir los requisitos de calidad;
- permitir que el Router seleccione una alternativa compatible;
- permitir que el Observer degrade a otro modelo ligero;
- permitir que el Auditor degrade o se ejecute con menor frecuencia;
- permitir desactivar `WORLD_OBSERVER` si no existe modelo compatible, autorizado y dentro de presupuesto;
- permitir desactivar `WORLD_AUDITOR` si no existe modelo compatible, autorizado y dentro de presupuesto;
- impedir que cualquiera de esas desactivaciones impida jugar;
- mantener la simulación autoritativa completamente funcional sin ambos servicios;
- permitir un fallback local basado en métricas, invariantes y validadores deterministas;
- permitir registrar que la cobertura inteligente está degradada únicamente en herramientas técnicas;
- permitir reactivar automáticamente o manualmente el servicio cuando vuelva a existir capacidad.

### N. Presupuesto y frecuencia

- integrarse con el Sistema de Presupuesto, Coste y Control de Uso de IA antes de cada operación;
- respetar RPM;
- respetar TPM;
- respetar RPD;
- respetar concurrencia;
- respetar presupuesto económico;
- respetar créditos;
- respetar cuotas gratuitas;
- respetar reservas de uso;
- impedir que el Observer monopolice una cuota compartida;
- permitir límites por hora de juego;
- permitir límites por día real;
- permitir límites por día de juego cuando resulte útil;
- permitir batching para reducir llamadas;
- permitir reducir tokens mediante deltas;
- permitir resúmenes acumulativos;
- permitir compresión semántica;
- evitar reenviar contexto estático innecesario;
- mantener suficientes referencias para poder reconstruir hechos cuando hagan falta;
- medir consumo real durante pruebas;
- utilizar dichas pruebas para determinar la frecuencia efectiva de producción;
- no fijar definitivamente una frecuencia de un minuto, noventa segundos o cualquier otro valor hasta disponer de métricas reales;
- permitir que una frecuencia aparentemente continua sea en realidad event-driven y adaptativa;
- priorizar calidad de observación útil sobre número máximo de llamadas.

### O. Persistencia

- conservar únicamente el estado del Observer que sea necesario para continuidad, auditoría o eficiencia;
- permitir persistir `World Intelligence State` como caché derivada no autoritativa;
- marcar revisión de los hechos base;
- invalidarlo cuando no corresponda a la revisión vigente;
- permitir regenerarlo;
- conservar auditorías de salud relevantes;
- conservar alertas técnicas pendientes;
- conservar solicitudes de diagnóstico pendientes;
- conservar referencias a paquetes exportados cuando se decida mantenerlas;
- conservar estado suficiente para no repetir innecesariamente una investigación ya resuelta;
- impedir que una caché de IA sea requisito indispensable para cargar un save;
- permitir reconstrucción sin proveedor externo;
- mantener separada persistencia técnica de historia del mundo.

### P. Rendimiento y ejecución asíncrona

- ejecutar las llamadas de IA fuera del camino crítico de frames y gameplay;
- impedir que una latencia de API congele la simulación;
- permitir trabajos asíncronos;
- permitir timeout;
- permitir cancelación;
- permitir reintentos controlados;
- permitir backoff;
- permitir que un resultado llegue tarde y sea descartado si su revisión ya no es aplicable;
- validar siempre la revisión antes de aceptar una respuesta;
- permitir coalescing de lotes pendientes;
- evitar colas ilimitadas;
- permitir descartar observaciones de baja prioridad que hayan quedado obsoletas;
- preservar acontecimientos críticos aunque un lote anterior sea sustituido;
- permitir procesamiento durante pausas técnicas cuando resulte útil sin confundirlo con tiempo de juego;
- no alterar resultados del mundo por el orden accidental en que respondan proveedores externos.

### Q. Herramientas de desarrollo y debug

- permitir inspeccionar cada lote enviado al Observer;
- permitir inspeccionar cada respuesta;
- permitir ver hechos fuente;
- permitir ver hipótesis;
- permitir ver evidencias a favor y en contra;
- permitir ver revisiones;
- permitir ver proveedor y modelo seleccionados;
- permitir ver latencia;
- permitir ver tokens;
- permitir ver coste;
- permitir ver cuota restante cuando el proveedor la exponga;
- permitir ver por qué el Router eligió un modelo;
- permitir forzar un modelo en escenarios de test;
- permitir simular retirada de un proveedor;
- permitir simular free tier agotado;
- permitir simular rate limit;
- permitir simular timeout;
- permitir simular respuesta inválida;
- permitir simular alucinaciones de referencias;
- permitir probar recuperación;
- permitir ejecutar auditoría manual;
- permitir generar un ZIP manual para pruebas;
- permitir importar un `RepairProposal` de prueba;
- impedir aplicar propuestas de prueba sobre saves reales sin autorización explícita;
- permitir comparar dos modelos sobre el mismo contexto;
- permitir golden tests con situaciones conocidas;
- permitir escenarios en los que un mundo extraordinario sea correcto;
- permitir escenarios en los que una anomalía sea real;
- medir falsos positivos;
- medir falsos negativos;
- medir calidad de clasificación;
- medir frecuencia de escalado;
- medir tamaño medio de los paquetes;
- medir cuánta información resulta realmente necesaria para diagnóstico.

### R. Pruebas obligatorias de diseño

- comprobar que un golpe de Estado legítimo en Hallheim no genere una reparación;
- comprobar que el jugador situado en Treskal no reciba información omnisciente sobre ese golpe si no existe canal de conocimiento válido;
- comprobar que una guerra legítima no sea tratada como bug por ser destructiva;
- comprobar que la concentración extrema de riqueza pueda clasificarse como emergente válida si procede de reglas correctas;
- comprobar un multiplicador aplicado dos veces y exigir `TECHNICAL_ANOMALY`;
- comprobar relaciones degradadas por error de código;
- comprobar referencias a entidades inexistentes;
- comprobar un sistema detenido durante demasiados ciclos;
- comprobar una falsa alarma del Auditor;
- comprobar retirada de la falsa alarma ante evidencia nueva;
- comprobar caída del proveedor del Observer;
- comprobar caída del proveedor del Auditor;
- comprobar agotamiento de cuota;
- comprobar retirada definitiva de un modelo;
- comprobar sustitución de proveedor sin tocar lógica de gameplay;
- comprobar Observer desactivado con partida completamente jugable;
- comprobar Auditor desactivado con partida completamente jugable;
- comprobar generación íntegra del ZIP;
- comprobar hashes/manifest;
- comprobar que el ZIP no contiene credenciales;
- comprobar revisión externa que concluye «todo correcto» sin revelar spoilers al jugador;
- comprobar revisión externa que detecta fallo real;
- comprobar importación de JSON correcto;
- comprobar rechazo de JSON malformado;
- comprobar rechazo de referencias inventadas;
- comprobar rechazo de parche dirigido a otro save;
- comprobar rechazo de parche que intenta borrar hechos legítimos;
- comprobar dry-run;
- comprobar backup;
- comprobar aplicación transaccional;
- comprobar rollback;
- comprobar auditoría posterior a reparación;
- comprobar que el resultado final preserva hechos válidos anteriores al bug siempre que sea posible.

### S. Perfil inicial de referencia de modelos

El sistema deberá mantenerse independiente de proveedores, pero durante el desarrollo podrá utilizarse como punto de partida el siguiente reparto provisional, siempre sujeto a pruebas reales de calidad, latencia, cuota y coste:

- `WORLD_OBSERVER` → Gemini Flash-Lite 3.5;
- `WORLD_AUDITOR` → Gemini 3.8;
- `NPC_DIALOGUE_BASIC` → Mistral Small 4 y/o Gemini Flash-Lite 3.5;
- `NPC_DIALOGUE_MEDIUM` → Mistral Medium 3.5;
- `NPC_DECISION_MEDIUM` → Mistral Medium 3.5;
- `NPC_DECISION_COMPLEX` → Gemini 3.8;
- `EXTERNAL_MASTER_REPAIR` → ChatGPT Sol High utilizado externamente;
- permitir que una misma capacidad tenga varios proveedores elegibles;
- permitir que las pruebas determinen finalmente qué modelo resulta mejor para cada trabajo;
- impedir considerar cualquier free tier, crédito mensual, precio o cuota actual como contrato permanente del diseño.

## Depende de

- Núcleo de Partida
- Sistema de Estado del Mundo
- Sistema de Tiempo
- Sistema de Guardado y Carga
- Sistema de Entidades e Identidad
- Sistema de Datos, Configuración y Content Packs
- Sistema de Simulación, Planificación de Actualizaciones y Nivel de Detalle Lógico
- Sistema de Acciones, Reglas, Condiciones, Efectos y Validación de Gameplay
- Sistema de Conocimiento
- Sistema de Eventos, Sucesos y Acontecimientos Emergentes
- Sistema de Historia y Crónica del Mundo
- Sistema de Construcción y Gestión de Contexto para IA
- Sistema de Enrutado y Selección de Modelos de IA
- Sistema de Presupuesto, Coste y Control de Uso de IA
- Sistema de Validación, Esquemas y Contratos de IA
- Master Patch System
- Sistemas propietarios que proporcionen hechos, cambios, invariantes o diagnósticos mediante contratos registrados

## Lo utilizan

- Sistema Director de Partida
- Sistema de Partida Maestra y Magíster
- Master Patch System
- Sistema de Construcción y Gestión de Contexto para IA
- Sistema de Enrutado y Selección de Modelos de IA
- Sistema de Presupuesto, Coste y Control de Uso de IA
- Sistema de Validación, Esquemas y Contratos de IA
- Herramientas de Desarrollo y Debug
- Flujo de revisión externa y reparación autorizado

## Reutilización

RPG Core configurable.

La infraestructura destinada a observar cambios globales, construir inteligencia derivada, auditar la salud técnica de una simulación, proteger información player-safe, empaquetar evidencia, exportar diagnósticos, importar propuestas de reparación y validar su aplicación deberá ser independiente del universo de Nimroel.

Ninguna regla específica de Norgard, Hallheim, Treskal, Casas, personajes, sucesiones, política, economía o canon deberá formar parte obligatoria del núcleo. Cada videojuego deberá aportar sus propios dominios, invariantes, Content Packs, niveles de sensibilidad narrativa y contratos de diagnóstico.

Los nombres concretos de proveedores y modelos deberán permanecer en configuración sustituible. El mismo sistema deberá poder operar con proveedores futuros, modelos locales o incluso sin IA generativa, utilizando una cobertura degradada basada en reglas y validadores deterministas.

La distinción entre comportamiento emergente legítimo y fallo técnico deberá conservarse como principio general reutilizable: un simulador no debe corregir automáticamente una situación únicamente porque sea extrema, poco frecuente o narrativamente incómoda.

## Documentación técnica

Obligatoria.

Codex deberá crear y mantener la documentación técnica del sistema a medida que lo implemente y modifique.

La documentación deberá reflejar exclusivamente la implementación real existente en el repositorio e incluir, como mínimo:

- arquitectura;
- clases y componentes;
- archivos;
- estructuras y enums;
- API pública;
- flujo de datos;
- inicialización;
- dependencias;
- comunicación con otros sistemas;
- persistencia;
- decisiones técnicas relevantes;
- formato y versionado de `WorldObservationBatch`;
- formato y versionado de `WorldIntelligenceState`;
- formato y versionado de `WorldHealthAudit`;
- formato y versionado de paquetes forenses;
- formato y versionado de `RepairProposal`;
- política de spoilers y separación player-safe/developer-full;
- política de cuotas, frecuencia y degradación;
- integración con proveedores y Router;
- integración con Master Patch System;
- procedimiento de dry-run, backup, aplicación y rollback;
- pruebas y validaciones;
- métricas de falsos positivos y falsos negativos;
- limitaciones conocidas;
- elementos pertenecientes al RPG Core reutilizable;
- dependencias específicas de Nimroel;
- instrucciones necesarias para portar o reutilizar el sistema en otro videojuego.

La documentación deberá mantenerse actualizada y versionada junto con el código.

## Estado

Pendiente
