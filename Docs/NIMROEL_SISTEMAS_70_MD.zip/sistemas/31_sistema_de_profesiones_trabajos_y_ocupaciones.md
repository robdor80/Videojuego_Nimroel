# 31 · SISTEMA DE PROFESIONES, TRABAJOS Y OCUPACIONES

## Qué es

Gestiona las actividades profesionales, oficios, cargos, empleos y ocupaciones que pueden desempeñar los personajes dentro del mundo. Debe permitir que trabajar no sea únicamente una etiqueta de personaje, sino una actividad integrada con economía, horarios, organizaciones, producción, habilidades, posición social, relaciones y evolución personal.

## Debe permitir

- definir profesiones;
- definir oficios;
- definir empleos;
- definir ocupaciones temporales;
- definir cargos;
- definir trabajos institucionales;
- definir trabajos vinculados a organizaciones;
- definir trabajos independientes;
- diferenciar profesión aprendida de puesto de trabajo actual;
- permitir que un personaje conozca un oficio aunque no lo ejerza;
- permitir varios conocimientos profesionales por personaje;
- permitir ejercer varias actividades cuando las reglas lo permitan;
- asignar profesión a personajes;
- asignar puesto de trabajo;
- registrar lugar de trabajo;
- registrar empleador;
- registrar organización responsable;
- gestionar trabajadores autónomos;
- gestionar empleados;
- gestionar subordinados;
- gestionar superiores;
- gestionar compañeros de trabajo;
- gestionar jornadas laborales;
- gestionar horarios;
- gestionar turnos;
- gestionar días de descanso;
- permitir trabajos estacionales;
- permitir trabajos temporales;
- permitir trabajos permanentes;
- permitir contratos cuando el universo los contemple;
- gestionar salario;
- gestionar pagos por tarea;
- gestionar pagos en especie;
- gestionar trabajos sin remuneración cuando corresponda;
- gestionar obligaciones laborales;
- gestionar ausencias;
- gestionar abandono de un empleo;
- gestionar despidos;
- gestionar expulsiones;
- gestionar jubilación cuando proceda;
- gestionar promoción profesional;
- gestionar descenso de categoría;
- permitir ascenso por experiencia;
- permitir ascenso por relaciones;
- permitir ascenso por reputación;
- permitir ascenso por decisiones políticas u organizativas;
- permitir favoritismo;
- permitir nepotismo;
- permitir discriminaciones o restricciones sociales cuando formen parte de las reglas del universo;
- gestionar requisitos para ejercer una profesión;
- gestionar habilidades necesarias;
- gestionar conocimientos necesarios;
- gestionar experiencia profesional;
- gestionar aprendizaje;
- gestionar formación;
- gestionar aprendizaje mediante práctica;
- gestionar maestros y aprendices cuando corresponda;
- gestionar progresión profesional;
- permitir especialización;
- permitir pérdida de competencia por falta de práctica si el diseño lo requiere;
- influir en atributos o habilidades;
- influir en posición social;
- influir en reputación;
- influir en relaciones;
- influir en ingresos;
- influir en acceso a información;
- influir en acceso a lugares;
- influir en acceso a organizaciones;
- influir en permisos o privilegios;
- determinar qué actividades puede realizar un personaje;
- determinar qué herramientas necesita;
- determinar qué recursos consume;
- determinar qué bienes o servicios produce;
- integrarse con producción;
- integrarse con agricultura;
- integrarse con extracción de recursos;
- integrarse con comercio;
- integrarse con economía;
- integrarse con propiedad;
- integrarse con organizaciones;
- integrarse con localizaciones;
- integrarse con NPC;
- permitir que NPC busquen empleo;
- permitir que NPC abandonen trabajos;
- permitir que NPC cambien de profesión;
- permitir desempleo;
- permitir escasez de trabajadores;
- permitir exceso de mano de obra;
- permitir migraciones motivadas por oportunidades laborales;
- permitir contratación de trabajadores;
- permitir competencia por determinados puestos;
- permitir que organizaciones necesiten personal para funcionar;
- permitir que negocios reduzcan actividad por falta de trabajadores;
- permitir que actividades económicas requieran determinados perfiles profesionales;
- permitir que acontecimientos provoquen pérdida masiva de empleos;
- permitir creación de nuevos puestos por crecimiento económico;
- permitir desaparición de profesiones o empleos si cambian las circunstancias del mundo;
- gestionar profesiones legales;
- gestionar profesiones ilegales;
- permitir ocupaciones criminales;
- permitir empleos clandestinos;
- permitir trabajos militares;
- permitir trabajos administrativos;
- permitir trabajos políticos;
- permitir trabajos culturales, institucionales, académicos, ceremoniales o equivalentes cuando el universo los contemple;
- permitir trabajos artesanales;
- permitir trabajos comerciales;
- permitir trabajos agrícolas;
- permitir trabajos extractivos;
- permitir trabajos intelectuales;
- permitir profesiones sanitarias cuando existan;
- permitir actividades especializadas definidas por cada universo;
- registrar historial profesional;
- registrar antiguos empleadores;
- registrar antiguos cargos;
- registrar ascensos y despidos relevantes;
- permitir que el historial laboral influya en decisiones futuras;
- permitir recomendaciones;
- permitir referencias negativas;
- utilizar el Sistema de Conocimiento para controlar qué sabe un personaje sobre oportunidades laborales;
- impedir que NPC conozcan automáticamente todos los puestos disponibles;
- permitir rumores sobre trabajos disponibles;
- permitir información laboral falsa o desactualizada;
- permitir intermediarios o contactos;
- permitir que relaciones personales influyan en contrataciones;
- permitir que conflictos políticos o sociales afecten al empleo;
- permitir que guerras alteren la demanda de determinadas profesiones;
- permitir que el clima afecte a trabajos estacionales;
- permitir que la economía altere salarios y oportunidades;
- permitir simulación simplificada de profesiones y empleo en regiones no activas visualmente;
- permitir incorporar nuevas profesiones mediante datos sin modificar el núcleo;
- permitir incorporar profesiones propias de futuras regiones de Nimroel sin rehacer el sistema;
- permitir que Norgard utilice inicialmente solo su catálogo profesional;
- permitir que futuros territorios humanos y territorios élficos añadan profesiones, restricciones y estructuras laborales propias;
- proporcionar al Director información sobre desempleo, escasez de trabajadores, conflictos laborales y cambios profesionales relevantes;
- permitir que Magíster utilice la situación profesional de personajes y regiones como contexto narrativo sin alterar directamente los estados registrados;
- conservar toda la información profesional mediante guardado y carga.
## Depende de

- Núcleo de Partida
- Sistema de Estado del Mundo
- Sistema de Tiempo
- Sistema de Entidades e Identidad
- Sistema de Personajes
- Sistema de NPC
- Sistema de Relaciones
- Sistema de Conocimiento
- Sistema de Organizaciones y Facciones
- Sistema de Localizaciones y Estructura del Mundo
- Sistema de Propiedad y Posesiones
- Sistema de Economía y Recursos
## Lo utilizan

- Sistema de Personaje Jugador, Creación de Personaje y Nueva Partida
- Sistema de NPC
- Organizations
- Economy
- Trade System
- Production System
- Agriculture
- Resource Extraction
- Crime System
- Sistema de Justicia, Leyes y Jurisdicciones
- Reputation
- Politics
- Military System
- Events
- Quests
- Director
- Sistema de Historia y Crónica del Mundo
- Partida Maestra/Magíster
## Reutilización

RPG Core configurable. La infraestructura destinada a gestionar profesiones, puestos, horarios, empleo, experiencia laboral, progresión, contratación, salarios y relaciones laborales deberá ser reutilizable. Las profesiones concretas, requisitos, jerarquías, salarios, restricciones sociales, actividades permitidas y particularidades culturales o tecnológicas propias de Nimroel deberán definirse externamente mediante datos y configuración del universo. El sistema deberá permitir que cada región incorpore sus propias profesiones y reglas laborales sin modificar la arquitectura general, de forma que Norgard pueda funcionar

inicialmente de manera independiente y futuras regiones amplíen el catálogo cuando se incorporen al juego.

## Documentación técnica

Obligatoria. Codex deberá crear y mantener la documentación técnica del sistema a medida que lo implemente y modifique. La documentación deberá reflejar exclusivamente la implementación real existente en el repositorio e incluir, como mínimo:

- arquitectura;
- clases y componentes;
- archivos;
- estructuras y enums;
- API pública;
- flujo de datos;
- inicialización;
- dependencias;
- comunicación con otros sistemas;
- persistencia;
- decisiones técnicas relevantes;
- diferencias entre Windows y Android cuando existan;
- pruebas y validaciones;
- limitaciones conocidas;
- elementos pertenecientes al RPG Core reutilizable;
- dependencias específicas de Nimroel;
- instrucciones necesarias para portar o reutilizar el sistema en otro videojuego. La documentación deberá mantenerse actualizada y versionada junto con el código.
## Estado

Pendiente
