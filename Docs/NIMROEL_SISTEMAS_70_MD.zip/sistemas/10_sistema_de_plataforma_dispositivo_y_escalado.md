# 10 · SISTEMA DE PLATAFORMA, DISPOSITIVO Y ESCALADO

## Qué es

Detecta en qué plataforma y dispositivo se está ejecutando Nimroel RPG y adapta automáticamente presentación, controles, resolución, densidad de interfaz y calidad gráfica. Su objetivo es que el mismo juego funcione correctamente en Windows y Android sin depender de configuraciones manuales ni de una interfaz diseñada solo para una de las dos plataformas.

## Debe permitir

- detectar si el juego se ejecuta en Windows o Android;
- identificar resolución y relación de aspecto;
- adaptar la interfaz a distintas resoluciones;
- gestionar escalado DPI;
- mantener proporciones correctas en pantallas 16:10;
- permitir perfiles de validación para resoluciones objetivo concretas durante desarrollo sin hardcodearlas en el RPG Core;
- permitir validar dispositivos concretos mediante configuración y pruebas, manteniendo genérica la lógica de plataforma y escalado;
- evitar elementos cortados, solapados o demasiado pequeños;
- adaptar tamaños de texto, botones, paneles y márgenes;
- disponer de perfiles específicos por plataforma;
- permitir perfiles específicos por dispositivo cuando sea necesario;
- seleccionar configuraciones gráficas adecuadas al hardware;
- controlar resolución interna y resolución de salida;
- permitir diferentes niveles de calidad gráfica;
- adaptar efectos visuales según rendimiento disponible;
- permitir limitar FPS por plataforma;
- gestionar orientación y comportamiento de pantalla en Android;
- respetar áreas seguras de pantalla;
- adaptarse a posibles barras del sistema Android;
- detectar cambios de resolución durante la ejecución;
- permitir modo ventana, pantalla completa y otros modos compatibles en Windows;
- proporcionar al resto de sistemas información sobre plataforma y capacidades del dispositivo;
- permitir añadir nuevos dispositivos o plataformas sin rehacer la arquitectura y garantizar que las diferencias de rendimiento o presentación no modifiquen el significado lógico de la partida.
## Depende de

- Núcleo de Partida
## Lo utilizan

- Sistema de Interfaz de Usuario (UI/UX)
- Input System
- Rendering System
- Maps
- Combat
- Dialogs
- Inventory
- Menus
- Settngs
- Audio
- Performance System
- Sistema de Guardado y Carga
## Reutilización

RPG Core. La detección de plataforma, dispositivo, resolución, escalado, perfiles de hardware y adaptación Windows/Android deberá ser completamente reutilizable. Los dispositivos y resoluciones utilizados durante desarrollo podrán disponer de perfiles recomendados de proyecto, pero nunca constituir dependencias internas del RPG Core ni alterar las reglas lógicas de la partida.

## Documentación técnica

Obligatoria. Codex deberá crear y mantener la documentación técnica del sistema a medida que lo implemente y modifique. La documentación deberá reflejar exclusivamente la implementación real existente en el repositorio e incluir, como mínimo:

- arquitectura;
- clases y componentes;
- archivos;
- estructuras y enums;
- API pública;
- flujo de datos;
- inicialización;
- dependencias;
- comunicación con otros sistemas;
- persistencia;
- decisiones técnicas relevantes;
- diferencias entre Windows y Android cuando existan;
- pruebas y validaciones;
- limitaciones conocidas;
- elementos pertenecientes al RPG Core reutilizable;
- dependencias específicas de Nimroel;
- instrucciones necesarias para portar o reutilizar el sistema en otro videojuego. La documentación deberá mantenerse actualizada y versionada junto con el código.
## Estado

Pendiente
