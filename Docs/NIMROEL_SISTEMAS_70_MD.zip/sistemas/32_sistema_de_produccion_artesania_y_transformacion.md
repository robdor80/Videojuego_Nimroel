# 32 · SISTEMA DE PRODUCCIÓN, ARTESANÍA Y TRANSFORMACIÓN

## Qué es

Gestiona la creación, transformación y elaboración de bienes a partir de materias primas, recursos, herramientas, instalaciones, conocimientos y trabajo. Debe permitir que la producción forme parte real de la economía del mundo, conectando extracción de recursos, profesiones, comercio, propiedad, disponibilidad de materiales y capacidad productiva de personajes, talleres, organizaciones y asentamientos.

## Debe permitir

- definir procesos de producción;
- definir recetas de fabricación;
- definir fórmulas de transformación;
- definir materias primas necesarias;
- definir recursos intermedios;
- definir productos finales;
- definir subproductos;
- definir residuos cuando sean relevantes;
- definir cantidades necesarias;
- definir cantidades producidas;
- definir tiempos de fabricación;
- definir herramientas necesarias;
- definir instalaciones necesarias;
- definir profesiones necesarias;
- definir habilidades necesarias;
- definir conocimientos necesarios;
- definir requisitos técnicos;
- definir requisitos culturales cuando corresponda;
- permitir producción manual;
- permitir producción artesanal;
- permitir producción mediante talleres;
- permitir producción mediante instalaciones especializadas;
- permitir producción institucional;
- permitir producción controlada por organizaciones;
- permitir producción doméstica;
- permitir producción individual;
- permitir producción colectiva;
- permitir procesos con varias etapas;
- permitir cadenas de transformación;
- permitir que un producto sea materia prima de otro proceso;
- gestionar consumo de recursos;
- gestionar disponibilidad de materiales;
- impedir producción sin recursos suficientes;
- impedir producción sin herramientas necesarias;
- impedir producción sin instalaciones adecuadas;
- impedir producción sin conocimientos requeridos;
- permitir sustitución de materiales cuando una receta lo contemple;
- permitir distintas calidades de materias primas;
- permitir distintas calidades de producto final;
- calcular calidad según materiales;
- calcular calidad según habilidad del productor;
- calcular calidad según herramientas;
- calcular calidad según instalaciones;
- calcular calidad según tiempo dedicado;
- permitir errores de fabricación;
- permitir fallos;
- permitir pérdida parcial de recursos;
- permitir productos defectuosos;
- permitir reparación o reprocesado cuando corresponda;
- permitir desperdicio;
- permitir eficiencia variable;
- permitir mejoras productivas;
- permitir herramientas mejores;
- permitir instalaciones mejores;
- permitir aprendizaje de nuevas técnicas;
- permitir transmisión de conocimientos productivos;
- permitir secretos profesionales;
- permitir recetas desconocidas para determinados personajes;
- utilizar el Sistema de Conocimiento para determinar qué sabe fabricar cada personaje u organización;
- permitir descubrimiento de nuevas recetas;
- permitir aprendizaje mediante maestros;
- permitir aprendizaje mediante documentos;
- permitir aprendizaje mediante experimentación cuando el diseño lo contemple;
- gestionar producción por encargo;
- permitir pedidos de fabricación;
- permitir fabricación para consumo propio;
- permitir fabricación para venta;
- permitir fabricación para organizaciones;
- permitir fabricación militar;
- permitir fabricación ilegal;
- permitir talleres clandestinos;
- permitir producción de bienes restringidos;
- permitir falsificaciones cuando el diseño lo contemple;
- registrar propietario de materias primas;
- registrar propietario del producto resultante;
- gestionar cambios de propiedad derivados de encargos;
- asociar procesos productivos a localizaciones;
- asociar talleres a propiedades;
- asociar instalaciones a organizaciones;
- asociar trabajadores a procesos productivos;
- calcular costes de producción;
- calcular coste de materiales;
- calcular coste laboral;
- calcular costes de mantenimiento;
- calcular rentabilidad aproximada;
- proporcionar costes al Sistema de Economía;
- proporcionar bienes al Sistema de Comercio;
- consumir recursos procedentes de extracción;
- consumir productos agrícolas;
- permitir dependencia de recursos externos;
- permitir producción limitada por escasez;
- permitir interrupción por falta de materias primas;
- permitir interrupción por falta de trabajadores;
- permitir interrupción por guerra;
- permitir interrupción por clima;
- permitir interrupción por destrucción de instalaciones;
- permitir pérdida de capacidad productiva;
- permitir reconstrucción de capacidad productiva;
- permitir creación de nuevos talleres;
- permitir ampliación de talleres;
- permitir cierre de instalaciones;
- permitir abandono de instalaciones;
- permitir cambio de actividad productiva;
- permitir especialización regional;
- permitir especialización de asentamientos;
- permitir monopolios productivos;
- permitir concentración de determinados oficios;
- permitir competencia entre productores;
- influir en precios;
- influir en disponibilidad comercial;
- influir en riqueza de personajes;
- influir en riqueza de organizaciones;
- influir en empleo;
- influir en migraciones;
- influir en importancia económica de asentamientos;
- permitir que NPC decidan producir según demanda, recursos y conocimiento;
- permitir que NPC reduzcan o abandonen producción no rentable;
- permitir que NPC detecten oportunidades productivas según la información que conozcan;
- impedir que NPC conozcan automáticamente demanda o precios de todo el mundo;
- permitir simulación detallada de talleres relevantes;
- permitir simulación agregada de producción regional;
- mantener coherencia entre simulación detallada y agregada;
- evitar simular individualmente procesos irrelevantes cuando no sea necesario;
- mantener estadísticas productivas cuando sean útiles;
- registrar acontecimientos productivos relevantes;
- permitir crisis de producción;
- permitir recuperación productiva;
- integrarse con economía;
- integrarse con comercio;
- integrarse con profesiones;
- integrarse con propiedad;
- integrarse con organizaciones;
- integrarse con localizaciones;
- integrarse con inventarios;
- integrarse con agricultura;
- integrarse con extracción de recursos;
- integrarse con crimen y justicia;
- integrarse con guerra;
- permitir que cada región disponga de sus propios recursos, técnicas y procesos productivos;
- permitir que Norgard utilice inicialmente únicamente su contenido productivo;
- permitir añadir posteriormente procesos, talleres, materiales y tecnologías propios de otros territorios humanos y territorios élficos;
- impedir que la arquitectura dependa de un catálogo cerrado de recursos o recetas;
- permitir añadir nuevos procesos de producción mediante datos sin modificar el núcleo;
- proporcionar al Director información sobre escasez productiva, crecimiento, colapsos y dependencias relevantes;
- permitir que Magíster utilice la situación productiva como contexto narrativo sin alterar directamente los estados reales del sistema;
- conservar todo el estado productivo mediante guardado y carga.
## Depende de

- Núcleo de Partida
- Sistema de Estado del Mundo
- Sistema de Tiempo
- Sistema de Entidades e Identidad
- Sistema de Personajes
- Sistema de NPC
- Sistema de Conocimiento
- Sistema de Organizaciones y Facciones
- Sistema de Localizaciones y Estructura del Mundo
- Sistema de Propiedad y Posesiones
- Sistema de Economía y Recursos
- Sistema de Comercio y Mercados
- Sistema de Profesiones, Trabajos y Ocupaciones
## Lo utilizan

- Sistema de Personaje Jugador, Creación de Personaje y Nueva Partida
- Sistema de NPC
- Organizations
- Economy
- Trade System
- Professions
- Inventory
- Crafting Interface
- Agriculture
- Resource Extraction
- Property System
- Crime System
- Sistema de Justicia, Leyes y Jurisdicciones
- War System
- Events
- Quests
- Director
- Sistema de Historia y Crónica del Mundo
- Partida Maestra/Magíster
## Reutilización

RPG Core configurable. La infraestructura destinada a definir procesos productivos, recetas, requisitos, consumos, resultados, calidad, tiempos y capacidad productiva deberá ser reutilizable. Los materiales concretos, recetas, herramientas, instalaciones, conocimientos, técnicas, niveles tecnológicos y procesos específicos de Nimroel deberán definirse externamente mediante datos y configuración del universo. El sistema deberá permitir que cada región incorpore sus propios recursos, procesos y capacidades productivas sin modificar la arquitectura general, de forma que Norgard pueda constituir inicialmente el único contenido productivo disponible y futuras regiones amplíen el sistema progresivamente.

## Documentación técnica

Obligatoria. Codex deberá crear y mantener la documentación técnica del sistema a medida que lo implemente y modifique. La documentación deberá reflejar exclusivamente la implementación real existente en el repositorio e incluir, como mínimo:

- arquitectura;
- clases y componentes;
- archivos;
- estructuras y enums;
- API pública;
- flujo de datos;
- inicialización;
- dependencias;
- comunicación con otros sistemas;
- persistencia;
- decisiones técnicas relevantes;
- diferencias entre Windows y Android cuando existan;
- pruebas y validaciones;
- limitaciones conocidas;
- elementos pertenecientes al RPG Core reutilizable;
- dependencias específicas de Nimroel;
- instrucciones necesarias para portar o reutilizar el sistema en otro videojuego. La documentación deberá mantenerse actualizada y versionada junto con el código.
## Estado

Pendiente
