# 26 · SISTEMA DE GENERACIONES Y LEGADO

## Qué es

Gestiona la continuidad de personajes, familias, linajes, herencias y consecuencias a lo largo de largos periodos de tiempo. Debe permitir que una partida de Nimroel continúe más allá de la vida de un único personaje, conservando descendencia, patrimonio, reputación, conocimientos, enemigos, alianzas y efectos históricos entre generaciones.

## Debe permitir

- registrar genealogías;
- crear relaciones padre/madre/hijo;
- gestionar hermanos y parentescos;
- gestionar nacimientos;
- gestionar embarazos;
- calcular edades;
- gestionar crecimiento y maduración;
- gestionar fertilidad según reglas del mundo;
- gestionar parejas y descendencia;
- gestionar matrimonios y separaciones cuando corresponda;
- gestionar adopciones si el diseño lo contempla;
- gestionar muerte natural o provocada;
- mantener personajes fallecidos dentro del registro histórico;
- transferir propiedades mediante herencia;
- transferir dinero y recursos;
- transferir titulos;
- transferir posiciones sociales cuando proceda;
- transferir derechos sucesorios;
- gestionar disputas de herencia;
- gestionar sucesiones dentro de Casas, familias u organizaciones;
- transmitir determinados rasgos entre generaciones;
- permitir herencia de características cuando corresponda;
- transmitir cultura, educación y tradiciones familiares;
- transmitir información y conocimientos;
- distinguir conocimiento personal de conocimiento preservado por una familia o institución;
- permitir pérdida de conocimiento entre generaciones;
- conservar documentos, objetos o reliquias familiares;
- mantener memoria sobre antepasados relevantes;
- gestionar reputación familiar;
- gestionar prestigio y desprestigio heredado;
- permitir enemistades que sobrevivan a sus protagonistas originales;
- permitir alianzas entre familias;
- permitir deudas y obligaciones heredadas cuando las reglas lo contemplen;
- registrar hechos históricos asociados a un linaje;
- mantener consecuencias provocadas por generaciones anteriores;
- permitir que descendientes reaccionen ante acciones realizadas por sus antepasados;
- permitir cambio de personaje jugador por muerte, sucesión u otros mecanismos previstos;
- permitir continuar una partida con un descendiente;
- mantener continuidad narrativa durante el cambio generacional;
- permitir desaparición completa de un linaje;
- permitir nacimiento de nuevos linajes;
- permitir ascenso y caída de Casas familiares;
- integrarse con política, economía y organizaciones;
- integrarse con propiedad territorial;
- integrarse con guerras y conflictos;
- permitir simulaciones de décadas sin necesidad de mantener todos los personajes a máximo nivel de detalle;
- mantener coherencia temporal durante simulaciones prolongadas;
- proporcionar al Director información sobre cambios generacionales relevantes;
- permitir que Magíster utilice el legado histórico como contexto narrativo sin alterar arbitrariamente los hechos registrados;
- conservar toda la información generacional mediante guardado y carga.
## Depende de

- Núcleo de Partida
- Sistema de Estado del Mundo
- Sistema de Tiempo
- Sistema de Entidades e Identidad
- Sistema de Personajes
- Sistema de Relaciones
- Sistema de Conocimiento
## Lo utilizan

- Sistema de NPC
- Organizations
- Economy
- Property System
- Politics
- Diplomacy
- Reputation
- Crime System
- Knowledge System
- Events
- Quests
- Director
- Sistema de Historia y Crónica del Mundo
- Partida Maestra/Magíster
## Reutilización

RPG Core configurable. La infraestructura de genealogías, nacimiento, envejecimiento, muerte, sucesión, herencia y continuidad generacional deberá ser reutilizable.

Longevidad de las razas, fertilidad, edades de madurez, sistemas sucesorios, tradiciones familiares y demás reglas específicas de Nimroel deberán definirse externamente como configuración del universo.

## Documentación técnica

Obligatoria. Codex deberá crear y mantener la documentación técnica del sistema a medida que lo implemente y modifique. La documentación deberá reflejar exclusivamente la implementación real existente en el repositorio e incluir, como mínimo:

- arquitectura;
- clases y componentes;
- archivos;
- estructuras y enums;
- API pública;
- flujo de datos;
- inicialización;
- dependencias;
- comunicación con otros sistemas;
- persistencia;
- decisiones técnicas relevantes;
- diferencias entre Windows y Android cuando existan;
- pruebas y validaciones;
- limitaciones conocidas;
- elementos pertenecientes al RPG Core reutilizable;
- dependencias específicas de Nimroel;
- instrucciones necesarias para portar o reutilizar el sistema en otro videojuego. La documentación deberá mantenerse actualizada y versionada junto con el código.
## Estado

Pendiente
