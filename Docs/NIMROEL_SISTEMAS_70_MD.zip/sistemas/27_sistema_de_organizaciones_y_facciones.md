# 27 · SISTEMA DE ORGANIZACIONES Y FACCIONES

## Qué es

Gestiona todas las organizaciones estructuradas que existen dentro del mundo: Casas, gremios, órdenes, instituciones, compañías, ejércitos, hermandades, bandas, gobiernos, asociaciones y cualquier otra agrupación con identidad propia. Debe permitir que estas organizaciones existan y evolucionen de forma independiente del jugador, manteniendo miembros, jerarquías, recursos, objetivos, relaciones internas y externas, conocimiento colectivo y continuidad histórica.

## Debe permitir

- crear organizaciones definidas manualmente;
- crear organizaciones surgidas dinámicamente durante una partida;
- asignar una identidad persistente a cada organización;
- distinguir distintos tipos de organización;
- gestionar nombre, símbolos, sede, territorio y características propias;
- gestionar miembros;
- gestionar altas, bajas y expulsiones;
- gestionar rangos y jerarquías internas;
- gestionar cargos;
- gestionar liderazgo;
- gestionar procesos de sucesión;
- permitir organizaciones con estructuras jerárquicas diferentes;
- permitir organizaciones sin líder único;
- gestionar requisitos de ingreso;
- gestionar obligaciones de los miembros;
- gestionar privilegios derivados de la pertenencia;
- gestionar objetivos a corto, medio y largo plazo;
- gestionar intereses colectivos;
- gestionar recursos propios;
- gestionar dinero y patrimonio;
- gestionar propiedades;
- gestionar sedes, instalaciones y territorios;
- gestionar inventarios o recursos institucionales;
- gestionar reputación de la organización;
- gestionar prestigio, poder e influencia;
- gestionar relaciones entre organizaciones;
- permitir alianzas;
- permitir rivalidades;
- permitir enemistades;
- permitir pactos y acuerdos;
- permitir vasallaje, dependencia o subordinación cuando corresponda;
- permitir fusiones;
- permitir divisiones internas;
- permitir escisiones;
- permitir desaparición de organizaciones;
- permitir creación de organizaciones sucesoras;
- mantener continuidad histórica cuando una organización desaparezca;
- gestionar conflictos internos;
- gestionar luchas por el poder;
- permitir conspiraciones;
- permitir traiciones;
- gestionar posiciones políticas internas;
- permitir facciones internas dentro de una misma organización;
- permitir que miembros individuales tengan intereses distintos a los de la organización;
- gestionar decisiones colectivas;
- permitir distintos mecanismos de decisión según el tipo de organización;
- gestionar conocimiento institucional;
- conservar información, aunque mueran los miembros que originalmente la conocían cuando exista un mecanismo institucional para preservarla;
- controlar qué información conoce realmente cada organización;
- gestionar secretos institucionales;
- gestionar relaciones con personajes individuales;
- permitir que un personaje pertenezca a varias organizaciones cuando las reglas lo permitan;
- detectar incompatibilidades entre pertenencias;
- permitir abandono voluntario;
- permitir expulsiones;
- permitir ascensos y descensos;
- permitir sucesión hereditaria cuando corresponda;
- integrarse con familias, Casas y linajes;
- integrarse con economía;
- integrarse con comercio;
- integrarse con propiedad;
- integrarse con política;
- integrarse con diplomacia;
- integrarse con crimen y justicia;
- integrarse con guerras y conflictos;
- integrarse con reputación;
- integrarse con profesiones;
- integrarse con conocimiento;
- influir en comportamiento y decisiones de NPC;
- generar consecuencias para miembros por acciones realizadas en nombre de la organización;
- permitir que acciones de miembros afecten a la reputación colectiva;
- permitir que la organización actúe, aunque ninguno de sus miembros esté fisicamente cargado en escena;
- permitir simulación simplificada de organizaciones alejadas o temporalmente irrelevantes;
- mantener evolución institucional durante largos periodos de tiempo;
- permitir ascenso, decadencia y desaparición a lo largo de generaciones;
- registrar acontecimientos históricos relevantes asociados a cada organización;
- proporcionar al Director información sobre poder, conflictos, objetivos y evolución de las organizaciones;
- permitir que Magíster utilice las organizaciones como contexto narrativo sin modificar directamente su estado real;
- conservar toda la información mediante guardado y carga.
## Depende de

- Núcleo de Partida
- Sistema de Estado del Mundo
- Sistema de Tiempo
- Sistema de Entidades e Identidad
- Sistema de Personajes
- Sistema de NPC
- Sistema de Relaciones
- Sistema de Conocimiento
- Sistema de Generaciones y Legado
## Lo utilizan

- Sistema de NPC
- Economy
- Property System
- Politics
- Diplomacy
- Crime System
- Sistema de Justicia, Leyes y Jurisdicciones
- Reputation
- Professions
- Trade
- War System
- Combat
- Knowledge System
- Generations
- Events
- Quests
- Director
- Sistema de Historia y Crónica del Mundo
- Partida Maestra/Magíster
## Reutilización

RPG Core configurable. La infraestructura destinada a crear organizaciones, gestionar miembros, jerarquías, recursos, objetivos, relaciones, conocimiento institucional y evolución histórica deberá ser reutilizable. Los tipos concretos de organización, nombres, rangos, estructuras políticas, Casas, órdenes, gremios, instituciones y reglas particulares de Nimroel deberán definirse externamente mediante datos y configuración del universo.

## Documentación técnica

Obligatoria. Codex deberá crear y mantener la documentación técnica del sistema a medida que lo implemente y modifique. La documentación deberá reflejar exclusivamente la implementación real existente en el repositorio e incluir, como mínimo:

- arquitectura;
- clases y componentes;
- archivos;
- estructuras y enums;
- API pública;
- flujo de datos;
- inicialización;
- dependencias;
- comunicación con otros sistemas;
- persistencia;
- decisiones técnicas relevantes;
- diferencias entre Windows y Android cuando existan;
- pruebas y validaciones;
- limitaciones conocidas;
- elementos pertenecientes al RPG Core reutilizable;
- dependencias específicas de Nimroel;
- instrucciones necesarias para portar o reutilizar el sistema en otro videojuego. La documentación deberá mantenerse actualizada y versionada junto con el código.
## Estado

Pendiente
