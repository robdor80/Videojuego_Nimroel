# 45 · SISTEMA DE COMBATE

## Qué es

Gestiona enfrentamientos fisicos entre personajes, grupos y criaturas, resolviendo acciones ofensivas, defensivas, movimiento, daño, estados, equipamiento y consecuencias permanentes sobre el mundo. Debe permitir que el combate forme parte de la simulación general de Nimroel y no funcione como un minijuego aislado: heridas, muertes, objetos utilizados, relaciones, delitos, reputación, conocimiento y acontecimientos producidos durante un enfrentamiento deberán continuar existiendo después de que este termine.

## Debe permitir

- iniciar un combate;
- finalizar un combate;
- identificar participantes;
- permitir combates entre el jugador y NPC;
- permitir combates exclusivamente entre NPC;
- permitir enfrentamientos individuales;
- permitir enfrentamientos entre varios participantes;
- permitir enfrentamientos entre grupos;
- permitir intervención de nuevos participantes durante un combate;
- permitir huida;
- permitir rendición;
- permitir retirada;
- permitir incapacitación;
- permitir captura cuando corresponda;
- permitir muerte;
- distinguir aliados, enemigos y participantes neutrales;
- permitir cambios de bando cuando las circunstancias lo justifiquen;
- gestionar objetivos de combate;
- gestionar selección de objetivos;
- gestionar prioridades de ataque;
- gestionar posición relativa de los participantes;
- gestionar distancia;
- gestionar alcance;
- gestionar movimiento durante el enfrentamiento;
- gestionar aproximación;
- gestionar alejamiento;
- gestionar persecución;
- gestionar bloqueo del paso cuando corresponda;
- gestionar ataques;
- gestionar defensas;
- gestionar esquivas;
- gestionar bloqueos;
- gestionar paradas;
- gestionar contraataques cuando las reglas lo contemplen;
- gestionar precisión;
- gestionar probabilidad de impacto;
- gestionar daño;
- distinguir tipos de daño;
- aplicar daño al Sistema de Salud;
- producir heridas;
- producir incapacidades;
- producir estados temporales;
- producir estados permanentes;
- permitir golpes críticos si las reglas de combate los contemplan;
- gestionar protección;
- gestionar armaduras;
- gestionar armas;
- gestionar escudos cuando existan;
- gestionar herramientas utilizadas como armas cuando proceda;
- gestionar combate sin armas;
- gestionar distintos estilos de combate;
- gestionar habilidades de combate;
- gestionar experiencia relevante;
- permitir diferencias de habilidad entre combatientes;
- permitir ventajas derivadas de entrenamiento;
- permitir desventajas provocadas por heridas;
- permitir desventajas provocadas por agotamiento;
- permitir que el equipamiento influya en el resultado;
- permitir que el terreno influya en el combate;
- permitir que determinadas localizaciones impongan restricciones;
- permitir emboscadas;
- permitir ataques sorpresa;
- permitir que el conocimiento previo influya en decisiones tácticas;
- permitir que un personaje desconozca la presencia de un enemigo;
- permitir identificación incorrecta de participantes cuando las circunstancias lo justifiquen;
- permitir que NPC decidan combatir;
- permitir que NPC decidan huir;
- permitir que NPC se rindan;
- permitir que NPC protejan a otros personajes;
- permitir que NPC ayuden a aliados;
- permitir que NPC cambien de prioridad según evolucione el enfrentamiento;
- utilizar personalidad, relaciones, miedo, lealtad y motivaciones para influir en decisiones;
- permitir que un NPC evite enfrentamientos claramente desfavorables cuando su comportamiento lo justifique;
- permitir comportamientos desesperados;
- permitir comportamientos heroicos;
- permitir comportamientos cobardes;
- permitir decisiones irracionales cuando sean coherentes con el personaje;
- gestionar moral individual;
- permitir moral de grupo cuando corresponda;
- permitir ruptura de la moral;
- permitir pánico;
- permitir retirada colectiva;
- permitir persecución de enemigos derrotados cuando corresponda;
- permitir saqueo posterior mediante el Sistema de Objetos e Inventario;
- mantener propiedad de objetos durante y después del combate;
- permitir pérdida de armas u objetos;
- permitir destrucción o deterioro de equipamiento;
- permitir consumo de objetos durante el enfrentamiento;
- permitir utilización de medicamentos o recursos cuando las reglas lo permitan;
- permitir combate dentro de edificios;
- permitir combate en exteriores;
- permitir combate en caminos;
- permitir combate durante viajes cuando proceda;
- permitir combates vinculados a guerras;
- permitir combates vinculados a delitos;
- permitir legítima defensa según las reglas legales de cada territorio;
- permitir agresiones;
- permitir asesinatos;
- permitir que testigos observen un combate;
- registrar quién pudo observar cada acción relevante;
- transmitir la información observada al Sistema de Conocimiento;
- impedir que personajes ausentes conozcan automáticamente el resultado;
- permitir versiones contradictorias de un enfrentamiento;
- generar pruebas o evidencias cuando corresponda;
- integrarse con crimen y justicia;
- integrarse con relaciones;
- modificar relaciones a consecuencia del combate;
- modificar reputación;
- modificar afiliaciones u hostilidades cuando proceda;
- provocar consecuencias políticas;
- provocar consecuencias diplomáticas;
- provocar consecuencias familiares;
- provocar venganzas;
- provocar sucesiones por muerte;
- permitir que una muerte cambie liderazgo de organizaciones;
- registrar enfrentamientos históricos relevantes;
- permitir eventos derivados del resultado de un combate;
- permitir misiones derivadas del resultado de un combate;
- mantener separados el cálculo lógico del combate y su representación visual;
- permitir que la lógica de combate pueda evolucionar sin rehacer su presentación;
- permitir representación visual adaptada al estilo 2D de Nimroel dentro de UE5;
- permitir animaciones, efectos, sonidos e información visual sin convertir dichos elementos en fuente de verdad del combate;
- funcionar correctamente mediante teclado y ratón en Windows;
- funcionar completamente mediante control táctil en Android;
- adaptar controles y HUD de combate a cada plataforma;
- evitar acciones esenciales dependientes exclusivamente de hover o clic derecho;
- permitir pausas o modos de interacción adecuados al diseño final del combate;
- permitir configuraciones de velocidad cuando el sistema de juego lo requiera;
- mantener determinismo suficiente para evitar estados incoherentes;
- evitar que una animación o efecto visual pueda alterar por sí mismo la lógica registrada;
- permitir simulación simplificada de enfrentamientos lejanos al jugador;
- permitir resolver conflictos entre NPC sin necesidad de cargar fisicamente el escenario;
- mantener coherencia entre combate simulado y combate visualmente representado;
- permitir enfrentamientos masivos mediante niveles de abstracción cuando el número de participantes lo requiera;
- evitar crear un Actor de UE5 de alta complejidad para cada combatiente de una batalla que no esté siendo visualizada;
- permitir que otros sistemas soliciten la resolución de un enfrentamiento;
- impedir que sistemas externos modifiquen arbitrariamente resultados ya confirmados;
- permitir que el Director detecte oportunidades de conflicto sin decidir fraudulentamente el resultado;
- permitir que Magíster utilice un combate y sus consecuencias como contexto narrativo sin modificar directamente el resultado real;
- permitir añadir nuevas armas, armaduras, estilos, habilidades, criaturas y reglas mediante datos;
- permitir que Norgard incluya inicialmente su propio contenido de combate;
- permitir incorporar posteriormente unidades, armas, estilos y reglas particulares de otros territorios humanos y territorios élficos;
- permitir que diferentes razas tengan características de combate configurables;
- evitar incorporar reglas exclusivas de Nimroel directamente en el núcleo técnico;
- permitir reutilizar el mismo sistema en universos con reglas de combate diferentes;
- conservar participantes, resultados, heridas, muertes y consecuencias relevantes mediante guardado y carga.
## Depende de

- Núcleo de Partida
- Sistema de Estado del Mundo
- Sistema de Tiempo
- Sistema de Entidades e Identidad
- Sistema de Plataforma, Dispositivo y Escalado
- Sistema de Entrada y Controles
- Sistema de Interfaz de Usuario (UI/UX)
- Sistema de Personajes
- Sistema de NPC
- Sistema de Relaciones
- Sistema de Conocimiento
- Sistema de Organizaciones y Facciones
- Sistema de Localizaciones y Estructura del Mundo
- Sistema de Objetos, Inventario y Equipamiento
- Sistema de Salud, Heridas, Enfermedades y Estado Físico
## Lo utilizan

- Sistema de Personaje Jugador, Creación de Personaje y Nueva Partida
- Sistema de NPC
- Organizations
- Crime System
- Sistema de Justicia, Leyes y Jurisdicciones
- Reputation
- War System
- Sistema de Viaje, Desplazamiento y Rutas
- Exploration
- Health System
- Inventory
- Generations
- Knowledge System
- Events
- Quests
- Director
- Sistema de Historia y Crónica del Mundo
- Partida Maestra/Magíster
## Reutilización

RPG Core configurable. La infraestructura destinada a gestionar participantes, objetivos, acciones, ataques, defensas, daño, movimiento, moral, resolución y consecuencias de los enfrentamientos deberá ser reutilizable. Las armas, armaduras, estilos de lucha, habilidades, fórmulas, capacidades raciales, reglas tácticas y demás contenido específico de Nimroel deberán definirse externamente mediante datos y configuración del universo. La lógica del combate deberá mantenerse separada de su representación visual, permitiendo reutilizar el mismo núcleo técnico con otros estilos gráficos, interfaces y universos. El sistema deberá permitir incorporar progresivamente contenido de combate por regiones, de forma que Norgard constituya inicialmente el contenido disponible y futuras regiones humanas, élficas u otras puedan añadirse sin modificar la arquitectura del RPG Core.

## Documentación técnica

Obligatoria. Codex deberá crear y mantener la documentación técnica del sistema a medida que lo implemente y modifique. La documentación deberá reflejar exclusivamente la implementación real existente en el repositorio e incluir, como mínimo:

- arquitectura;
- clases y componentes;
- archivos;
- estructuras y enums;
- API pública;
- flujo de datos;
- inicialización;
- dependencias;
- comunicación con otros sistemas;
- persistencia;
- decisiones técnicas relevantes;
- diferencias entre Windows y Android cuando existan;
- pruebas y validaciones;
- limitaciones conocidas;
- elementos pertenecientes al RPG Core reutilizable;
- dependencias específicas de Nimroel;
- instrucciones necesarias para portar o reutilizar el sistema en otro videojuego. La documentación deberá mantenerse actualizada y versionada junto con el código.
## Estado

Pendiente
