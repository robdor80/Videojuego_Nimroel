# 4 · SISTEMA DE ESTADO DEL MUNDO

## Qué es

Mantiene la representación actual de todo aquello que ha cambiado o puede cambiar dentro del mundo de Nimroel durante una partida. Es la fuente de verdad objetiva del estado dinámico de la partida: consolida y permite consultar el estado vigente de personajes, lugares, organizaciones, relaciones, conflictos, recursos, acontecimientos y cualquier otra información que deba persistir y

## Debe permitir

- almacenar el estado actual del mundo;
- distinguir entre datos fijos del universo y datos modificables de una partida;
- reflejar los cambios válidamente producidos por el jugador, NPC o sistemas de simulación mediante los sistemas propietarios correspondientes; impedir que el World State se utilice como vía para modificar directamente datos de dominio saltándose sus reglas, validaciones o APIs; consultar el estado actual de cualquier entidad relevante;
- mantener el estado objetivo de los personajes, incluyendo vida, muerte, desaparición u otros estados aplicables, sin confundir la realidad del mundo con lo que el jugador, un NPC o una organización conoce sobre ella;
- mantener estados de asentamientos, regiones y localizaciones;
- mantener estados de organizaciones, facciones y Casas;
- permitir representar y consultar relaciones persistentes entre entidades conservando la autoridad y semántica de dichas relaciones en sus sistemas propietarios;
- registrar consecuencias permanentes o temporales;
- mantener variables globales de la partida;
- representar cambios territoriales, políticos, económicos y sociales;
- permitir estados locales independientes entre regiones;
- conservar los efectos, estados y referencias a acontecimientos pasados que sigan siendo necesarios para representar la situación actual, delegando la crónica histórica de la partida en el Sistema de Historia y Crónica del Mundo;
- permitir que otros sistemas reaccionen ante cambios;
- soportar evolución del mundo aunque el jugador no participe directamente;
- preparar el estado para ser guardado y posteriormente reconstruido;
- permitir ampliar el mundo con nuevos tipos de información sin romper partidas existentes.
## Depende de

- Núcleo de Partida
- Sistema de Entidades e Identidad
## Lo utilizan

- Save/Load
- Time System
- Director
- Character System
- NPC
- Organizations
- Economy
- Crime System
- Knowledge System
- Generations
- Maps
- Quests/Events
- Combat
- Diplomacy
- Partida Maestra/Magíster
## Reutilización

RPG Core. Debe diseñarse como núcleo técnico completamente independiente del universo de Nimroel. No deberá contener personajes, razas, lugares, organizaciones, narrativa, reglas de lore ni ningún otro contenido específico de Nimroel. Deberá poder utilizarse como base de futuros videojuegos construidos sobre la misma arquitectura RPG.

## Documentación técnica

Obligatoria. Codex deberá crear y mantener la DOCUMENTACIÓN TÉCNICA del sistema a medida que lo implemente y modifique. La documentación deberá reflejar exclusivamente la implementación real existente en el repositorio e incluir, como mínimo:

- arquitectura;
- clases y componentes;
- archivos;
- estructuras y enums;
- API pública;
- flujo de datos;
- inicialización;
- dependencias;
- comunicación con otros sistemas;
- persistencia;
- decisiones técnicas relevantes;
- diferencias entre Windows y Android cuando existan;
- pruebas y validaciones;
- limitaciones conocidas;
- elementos pertenecientes al RPG Core reutilizable;
- dependencias específicas de Nimroel;
- instrucciones necesarias para portar o reutilizar el sistema en otro videojuego. La documentación deberá mantenerse actualizada y versionada junto con el código.
## Estado

Pendiente
