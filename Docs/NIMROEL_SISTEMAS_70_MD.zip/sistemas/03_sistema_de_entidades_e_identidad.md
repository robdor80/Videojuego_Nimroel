# 3 · SISTEMA DE ENTIDADES E IDENTIDAD

## Qué es

Define cómo se identifica de forma única cualquier elemento relevante del mundo de Nimroel. Proporciona una identidad estable a personajes, organizaciones, lugares, objetos importantes, eventos, propiedades y demás entidades persistentes, permitiendo que los distintos sistemas puedan referirse a ellas sin depender de actores concretos cargados en memoria.

## Debe permitir

- asignar identificadores únicos a las entidades e instancias persistentes;
- mantener identidades persistentes entre sesiones;
- distinguir tipos de entidades;
- localizar una entidad a partir de su identificador;
- mantener referencias válidas entre sistemas;
- relacionar personajes con lugares, organizaciones, objetos u otras entidades;
- evitar duplicados;
- permitir entidades existentes aunque su Actor de UE5 no esté cargado;
- separar identidad lógica de representación visual;
- permitir entidades creadas dinámicamente durante una partida y asignarles identidad persistente cuando deban existir individualmente;
- permitir entidades destruidas, muertas o desaparecidas sin perder su registro histórico;
- mantener referencias históricas a entidades que ya no existen fisicamente;
- permitir referencias persistentes entre entidades que puedan ser utilizadas por sistemas como Relaciones, Propiedad, Organizaciones o Generaciones, sin asumir la propiedad ni la semántica de dichas relaciones;;
- permitir que guardados y cargas reconstruyan referencias correctamente;
- permitir que distintos sistemas compartan información sobre una misma entidad;
- permitir expansión futura con nuevos tipos de entidades sin modificar el sistema base.
## Depende de

- Núcleo de Partida
## Lo utilizan

- Character System
- NPC
- Organizations
- Locations
- Items
- Economy
- Crime System
- Knowledge System
- Generations
- Relationships
- Events
- Quests
- Maps
- Director
- Save/Load
- Partida Maestra/Magíster
## Reutilización

RPG Core. El sistema de identificadores, referencias persistentes, tipos de entidad y resolución de referencias deberá ser completamente independiente del universo. No deberá asumir la existencia de razas, personajes, Casas, lugares u otras entidades exclusivas de Nimroel.

## Documentación técnica

Obligatoria. Codex deberá crear y mantener la documentación técnica del sistema a medida que lo implemente y modifique. La documentación deberá reflejar exclusivamente la implementación real existente en el repositorio e incluir, como mínimo:

- arquitectura;
- clases y componentes;
- archivos;
- estructuras y enums;
- API pública;
- flujo de datos;
- inicialización;
- dependencias;
- comunicación con otros sistemas;
- persistencia;
- decisiones técnicas relevantes;
- diferencias entre Windows y Android cuando existan;
- pruebas y validaciones;
- limitaciones conocidas;
- elementos pertenecientes al RPG Core reutilizable;
- dependencias específicas de Nimroel;
- instrucciones necesarias para portar o reutilizar el sistema en otro videojuego. La documentación deberá mantenerse actualizada y versionada junto con el código.
## Estado

Pendiente
