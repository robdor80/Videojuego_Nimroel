# 12 · SISTEMA DE ENTRADA Y CONTROLES

## Qué es

Gestiona todas las formas en las que el jugador interactúa con Nimroel RPG y traduce teclado, ratón, pantalla táctil y otros dispositivos compatibles en acciones del juego. Debe abstraer el dispositivo fisico utilizado para que los sistemas de jugabilidad no dependan directamente de una tecla, botón o gesto concreto.

## Debe permitir

- utilizar teclado y ratón en Windows;
- utilizar controles táctiles en Android;
- mantener las mismas acciones de juego independientemente del dispositivo;
- definir acciones de entrada abstractas;
- reasignar teclas y controles;
- guardar configuraciones personalizadas;
- distinguir pulsación, pulsación mantenida y liberación;
- gestionar doble clic o doble toque cuando sea necesario;
- gestionar rueda del ratón;
- gestionar arrastre con ratón;
- gestionar desplazamiento táctil;
- gestionar pinch-to-zoom;
- gestionar gestos táctiles cuando aporten utilidad;
- permitir seleccionar personajes, objetos y elementos del escenario;
- permitir interacción contextual;
- controlar navegación por menús;
- controlar mapas;
- controlar inventario;
- controlar diálogos;
- controlar combate;
- permitir atajos específicos de teclado en Windows;
- evitar que funciones importantes dependan exclusivamente de hover;
- proporcionar alternativas táctiles para funciones asociadas al clic derecho;
- cambiar automáticamente los controles mostrados en pantalla según el dispositivo;
- permitir interfaces diferentes para ratón/teclado y táctil sin cambiar la lógica del juego;
- bloquear o redirigir entradas cuando haya menús, diálogos u otras capas activas;
- gestionar prioridades cuando varias interfaces puedan recibir la misma entrada;
- permitir activar o desactivar grupos de controles según el estado de juego;
- soportar el sistema Enhanced Input de UE5;
- preparar soporte futuro para mando sin que sea obligatorio inicialmente.
## Depende de

- Núcleo de Partida
- Sistema de Plataforma, Dispositivo y Escalado
- Sistema de Configuración, Accesibilidad y Preferencias del Usuario
## Lo utilizan

- Sistema de Interfaz de Usuario (UI/UX)
- Sistema de Personaje Jugador, Creación de Personaje y Nueva Partida
- Maps
- Inventory
- Dialogs
- Combat
- Exploration
- Travel
- Menus
- Character Interaction
- Settngs
## Reutilización

RPG Core configurable.

La infraestructura de entrada, contextos, reasignación, teclado, ratón, táctil y futuros dispositivos deberá ser genérica. Las acciones concretas de Nimroel deberán definirse mediante configuraciones o mapas de acciones sustituibles para que otros videojuegos puedan utilizar el mismo sistema con controles diferentes.

## Documentación técnica

Obligatoria. Codex deberá crear y mantener la documentación técnica del sistema a medida que lo implemente y modifique. La documentación deberá reflejar exclusivamente la implementación real existente en el repositorio e incluir, como mínimo:

- arquitectura;
- clases y componentes;
- archivos;
- estructuras y enums;
- API pública;
- flujo de datos;
- inicialización;
- dependencias;
- comunicación con otros sistemas;
- persistencia;
- decisiones técnicas relevantes;
- diferencias entre Windows y Android cuando existan;
- pruebas y validaciones;
- limitaciones conocidas;
- elementos pertenecientes al RPG Core reutilizable;
- dependencias específicas de Nimroel;
- instrucciones necesarias para portar o reutilizar el sistema en otro videojuego. La documentación deberá mantenerse actualizada y versionada junto con el código.
## Estado

Pendiente
