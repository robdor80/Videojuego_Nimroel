# 6 · SISTEMA DE GUARDADO Y CARGA

## Qué es

Se encarga de persistir una partida de Nimroel y reconstruirla posteriormente manteniendo intacto su estado. Debe ser capaz de guardar no solo la posición del jugador, sino la evolución completa del mundo: tiempo, personajes, organizaciones, relaciones, eventos, economía, conocimiento, cambios territoriales y cualquier otro dato relevante generado durante la partida.

## Debe permitir

- guardar una partida manualmente;
- realizar guardados automáticos;
- cargar una partida existente;
- mantener varios archivos o ranuras de guardado;
- asociar cada guardado a una partida concreta;
- permitir que cada sistema propietario aporte mediante contratos definidos los datos persistentes necesarios de su dominio;
- coordinar la persistencia conjunta de dichos datos sin apropiarse de su semántica ni mantener copias paralelas innecesarias;
- persistir la fecha y hora del mundo;
- persistir el estado necesario del personaje jugador;
- persistir los estados necesarios de personajes y NPC;
- persistir organizaciones, relaciones, propiedades, localizaciones y demás entidades cuando corresponda;
- persistir acontecimientos ocurridos, estados pendientes y consecuencias relevantes;
- persistir estados económicos, comerciales, políticos, militares, sociales y de cualquier otro dominio cuando corresponda;
- persistir conocimiento, genealogías, linajes y demás información dinámica necesaria;
- persistir semillas, resultados procedurales, referencias, versiones y demás información necesaria para reconstruir correctamente los procesos que dependan de generación procedural;
- guardar resultados ya consolidados cuando formen parte del estado real de la partida, evitando recalcularlos o volver a generarlos innecesariamente al cargar;
- coordinar la reconstrucción de la partida al cargar, restaurando los datos persistentes mediante sus sistemas propietarios;
- reconstruir correctamente identidades y referencias entre entidades;
- garantizar que una entidad persistente conserve su identidad después de guardar y cargar;
- impedir duplicados provocados por una reconstrucción incorrecta;
- impedir que una carga vuelva a ejecutar operaciones, acontecimientos o resoluciones que ya habían quedado consolidados;
- permitir mecanismos de deduplicación e idempotencia cuando resulten necesarios;
- detectar datos corruptos;
- detectar datos incompletos;
- detectar datos incompatibles;
- detectar referencias inexistentes o inválidas;
- detectar versiones incompatibles;
- mantener versiones del formato de guardado;
- permitir migraciones entre versiones del juego;
- permitir migraciones específicas proporcionadas por los sistemas propietarios;
- evitar que una actualización inutilice partidas antiguas cuando sea razonablemente posible;
- permitir mantener datos legacy cuando resulten necesarios para cargar partidas antiguas;
- distinguir entre cambio de formato, migración de datos y modificación del estado narrativo de una partida;
- impedir que una migración técnica reescriba arbitrariamente hechos consolidados;
- permitir realizar copias de seguridad;
- permitir recuperación ante fallos de guardado;
- evitar sustituir un guardado válido por uno incompleto o corrupto;
- permitir estrategias seguras de escritura temporal y confirmación cuando resulte apropiado;
- permitir detectar una operación de guardado interrumpida;
- permitir recuperación controlada después de cierres inesperados;
- separar los datos estáticos procedentes del juego o de Content Packs de los datos dinámicos propios de una partida;
- registrar las versiones relevantes de los Content Packs y configuraciones utilizadas por una partida cuando sean necesarias para su reconstrucción;
- permitir determinar si una partida puede cargarse con la combinación actual de contenido instalado y habilitado;
- evitar copiar innecesariamente dentro del save definiciones estáticas que puedan referenciarse mediante identificadores estables;
- conservar las referencias necesarias aunque una definición haya sido modificada, retirada o sustituida en versiones posteriores;
- permitir que nuevos sistemas registren sus propios contratos de persistencia sin tener que modificar la lógica central del Sistema de Guardado y Carga;
- permitir que un sistema deje de existir o cambie su formato mediante migraciones controladas;
- guardar únicamente la información necesaria, evitando archivos innecesariamente grandes;
- evitar persistir caches u otros datos derivados que puedan reconstruirse de forma segura, salvo que hacerlo resulte necesario por rendimiento o coherencia;
- permitir reconstruir datos derivados cuando resulte seguro;
- mantener aislamiento absoluto entre partidas diferentes;
- impedir que los datos dinámicos de una partida contaminen otra;
- permitir múltiples partidas con evoluciones completamente diferentes utilizando las mismas definiciones estáticas;
- mantener resultados lógicos equivalentes entre Windows y Android;
- permitir formatos o estrategias técnicas de persistencia diferentes por plataforma cuando sea necesario, sin alterar el significado de los datos;
- contemplar cierres, suspensión y reanudación de la aplicación en Android;
- permitir pruebas automatizadas de guardado y carga;
- permitir pruebas de round-trip que comprueben que guardar y volver a cargar conserva el estado relevante;
- permitir pruebas con partidas pequeñas, grandes y de larga duración;
- permitir comprobar integridad después de una carga;
- permitir comparar estados antes y después de guardar y cargar durante desarrollo;
- proporcionar diagnósticos claros cuando una partida no pueda cargarse;
- identificar, cuando sea posible, el sistema, versión, dato o referencia causante del problema;
- permitir herramientas de inspección y debug de los datos persistidos;
- mantener la infraestructura de persistencia completamente separada del contenido específico de Nimroel.
## Depende de

- Núcleo de Partida
- Sistema de Entidades e Identidad
- Sistema de Estado del Mundo
- Sistema de Tiempo
- Sistema de Datos, Configuración y Content Packs
## Lo utilizan

- Todos los sistemas que mantengan información persistente.
- Especialmente:
- Character System
- NPC
- Organizations
- Economy
- Crime System
- Knowledge System
- Generations
- Director
- Maps
- Events
- Quests
- Climate System
- Partida Maestra/Magíster
## Reutilización

RPG Core. La infraestructura de persistencia, versionado, migración, recuperación y reconstrucción de partidas deberá ser independiente de Nimroel. Cada sistema deberá poder registrar sus propios datos persistentes mediante contratos genéricos, permitiendo reutilizar la misma arquitectura de guardado en futuros videojuegos.

## Documentación técnica

Obligatoria. Codex deberá crear y mantener la documentación técnica del sistema a medida que lo implemente y modifique. La documentación deberá reflejar exclusivamente la implementación real existente en el repositorio e incluir, como mínimo:

- arquitectura;
- clases y componentes;
- archivos;
- estructuras y enums;
- API pública;
- flujo de datos;
- inicialización;
- dependencias;
- comunicación con otros sistemas;
- persistencia;
- decisiones técnicas relevantes;
- diferencias entre Windows y Android cuando existan;
- pruebas y validaciones;
- limitaciones conocidas;
- elementos pertenecientes al RPG Core reutilizable;
- dependencias específicas de Nimroel;
- instrucciones necesarias para portar o reutilizar el sistema en otro videojuego. La documentación deberá mantenerse actualizada y versionada junto con el código.
## Estado

Pendiente
