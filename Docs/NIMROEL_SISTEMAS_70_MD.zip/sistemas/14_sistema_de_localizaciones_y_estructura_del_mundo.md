# 14 · SISTEMA DE LOCALIZACIONES Y ESTRUCTURA DEL MUNDO

## Qué es

Gestiona la estructura espacial lógica objetiva del mundo de juego y las localizaciones que existen, se contienen, se conectan, pueden visitarse o modificarse y sirven de referencia a personajes, organizaciones y sistemas. El descubrimiento y el conocimiento de esas localizaciones pertenecen a los sistemas especializados correspondientes. Debe representar Nimroel como una red coherente de continentes, regiones, territorios, asentamientos, barrios, edificios, interiores, caminos y lugares especiales, separando la existencia lógica de una localización de su representación visual concreta en Unreal Engine 5.

## Debe permitir

- crear localizaciones persistentes;
- asignar una identidad única a cada localización;
- distinguir diferentes tipos de localización;
- organizar localizaciones jerárquicamente;
- definir continentes;
- definir regiones;
- definir territorios;
- definir reinos o divisiones políticas cuando corresponda;
- definir asentamientos;
- definir ciudades;
- definir pueblos y aldeas;
- definir barrios o distritos;
- definir edificios;
- definir interiores;
- definir habitaciones o zonas internas cuando sea necesario;
- definir caminos, rutas y conexiones;
- definir localizaciones naturales;
- definir bosques, montañas, ríos, lagos, costas y otros elementos relevantes;
- definir ruinas, fortalezas, academias, cuevas y otros lugares especiales;
- permitir localizaciones creadas manualmente;
- permitir localizaciones generadas dinámicamente cuando el diseño lo requiera;
- mantener relaciones padre/hijo entre localizaciones;
- saber en qué localización se encuentra cualquier entidad;
- saber qué localizaciones están contenidas dentro de otras;
- definir conexiones entre localizaciones;
- definir rutas disponibles entre puntos;
- almacenar distancias lógicas;
- almacenar tiempos de viaje;
- almacenar dificultades de acceso;
- almacenar restricciones de acceso;
- gestionar entradas y salidas;
- permitir accesos secretos;
- permitir que una localización exista objetivamente aunque ninguna entidad la conozca todavía;
- proporcionar identidades y datos espaciales estables para que el Sistema de Exploración y el Sistema de Conocimiento gestionen su descubrimiento;
- permitir que el Sistema de Conocimiento mantenga información parcial, incorrecta o desactualizada sobre una localización sin alterar su estado objetivo;
- permitir representar objetivamente localizaciones con suficiente estructura para que el Sistema de Conocimiento distinga entre conocer su existencia y conocer su posición exacta;
- mantener la verdad geográfica separada de la información incorrecta o desactualizada que pueda poseer una entidad;
- diferenciar posición lógica de representación visual;
- permitir que una localización exista aunque su mapa o escena de UE5 no esté cargado;
- cargar representación visual únicamente cuando sea necesaria;
- descargar mapas o escenas sin destruir el estado lógico de la localización;
- mantener el estado persistente de una localización entre visitas;
- registrar cambios producidos dentro de una localización;
- permitir destrucción, reconstrucción o transformación de lugares;
- permitir referenciar propietarios o entidades responsables, conservando la autoridad de esas relaciones en el Sistema de Propiedad, Organizaciones u otros sistemas propietarios;
- permitir representar y consultar control territorial determinado por los sistemas políticos, militares u organizativos correspondientes;
- reflejar cambios de control político válidamente producidos por el Sistema Político u otros sistemas propietarios;
- reflejar ocupaciones militares determinadas por el Sistema de Guerra;
- permitir referenciar disputas territoriales gestionadas por los sistemas políticos, diplomáticos o militares correspondientes;
- permitir fronteras;
- permitir restricciones de paso;
- permitir referencias espaciales para que el Sistema de Población asocie habitantes y agregados a asentamientos y regiones;
- asociar organizaciones a sedes y territorios;
- asociar personajes a residencia, lugar de trabajo u otras ubicaciones habituales;
- permitir que hogares definidos por los sistemas correspondientes se vinculen a localizaciones;
- permitir que establecimientos definidos por los sistemas correspondientes se vinculen a localizaciones;
- representar edificios públicos como localizaciones sin asumir la propiedad de su función institucional;
- permitir que el Sistema de Propiedad vincule propiedades privadas con sus localizaciones;
- permitir existencia de localizaciones temporales;
- permitir campamentos;
- permitir mercados temporales;
- permitir zonas afectadas por acontecimientos;
- almacenar características ambientales relevantes;
- proporcionar información al sistema climático;
- proporcionar información al sistema de viaje;
- proporcionar información al sistema de navegación;
- proporcionar información al sistema económico;
- proporcionar información al sistema de propiedad;
- proporcionar información al sistema político;
- proporcionar información al sistema de crimen y justicia;
- permitir eventos asociados a lugares concretos;
- permitir que determinadas actividades solo puedan realizarse en tipos específicos de localización;
- permitir horarios de acceso;
- permitir cierres temporales;
- gestionar peligros asociados a una zona;
- permitir regiones inaccesibles debido a guerras, clima, destrucción u otros acontecimientos;
- mantener referencias a hechos históricos relevantes de una localización, delegando su crónica en el Sistema de Historia y Crónica del Mundo;
- registrar cambios de nombre cuando corresponda;
- conservar nombres históricos;
- permitir que una misma localización sea conocida con nombres diferentes por distintas culturas o personajes;
- proporcionar al Sistema de Conocimiento referencias espaciales objetivas sin asumir qué información conoce cada entidad;
- proporcionar la estructura geográfica objetiva que el Sistema de Mapas podrá representar mediante información player-safe;
- permitir que el Sistema de Mapas y el Sistema de Conocimiento filtren la representación sin modificar la geografia objetiva;
- permitir distintos niveles de detalle según la escala consultada;
- permitir simulación de regiones que no estén cargadas visualmente;
- proporcionar al Director contexto geográfico para generar o seleccionar acontecimientos;
- permitir que Magíster utilice la estructura espacial como contexto narrativo sin alterar directamente la verdad del mundo;
- conservar toda la estructura y sus modificaciones mediante guardado y carga.
## Depende de

- Núcleo de Partida
- Sistema de Entidades e Identidad
- Sistema de Estado del Mundo
- Sistema de Tiempo
- Sistema de Datos, Configuración y Content Packs
## Lo utilizan

- Sistema de Personaje Jugador, Creación de Personaje y Nueva Partida
- Sistema de NPC
- Organizations
- Maps
- Sistema de Viaje, Desplazamiento y Rutas
- Navigation System
- Property System
- Economy
- Trade
- Politics
- Diplomacy
- Crime System
- Sistema de Justicia, Leyes y Jurisdicciones
- Sistema Climático y Ambiental
- War System
- Combat
- Exploration
- Events
- Quests
- Director
- Sistema de Historia y Crónica del Mundo
- Partida Maestra/Magíster
## Reutilización

RPG Core configurable. La infraestructura encargada de representar jerarquías espaciales, conexiones, localizaciones persistentes, relaciones de contención, accesibilidad y estado lógico de los lugares deberá ser reutilizable. El descubrimiento, la cartografia y el conocimiento de esa geografia deberán permanecer en sus sistemas propietarios. Los continentes, regiones, ciudades, edificios, accidentes geográficos, nombres, fronteras, territorios y cualquier otra geografia concreta de Nimroel deberán proporcionarse externamente mediante datos y contenido específico del universo.

## Documentación técnica

Obligatoria. Codex deberá crear y mantener la documentación técnica del sistema a medida que lo implemente y modifique. La documentación deberá reflejar exclusivamente la implementación real existente en el repositorio e incluir, como mínimo:

- arquitectura;
- clases y componentes;
- archivos;
- estructuras y enums;
- API pública;
- flujo de datos;
- inicialización;
- dependencias;
- comunicación con otros sistemas;
- persistencia;
- decisiones técnicas relevantes;
- diferencias entre Windows y Android cuando existan;
- pruebas y validaciones;
- limitaciones conocidas;
- elementos pertenecientes al RPG Core reutilizable;
- dependencias específicas de Nimroel;
- instrucciones necesarias para portar o reutilizar el sistema en otro videojuego. La documentación deberá mantenerse actualizada y versionada junto con el código.
## Estado

Pendiente
