# 15 · SISTEMA DE PERSONAJES

## Qué es

Define la estructura base común de todos los personajes de Nimroel, tanto del personaje controlado por el jugador como de los NPC relevantes o secundarios. Es el punto común para la identidad persistente, los datos intrínsecos básicos del personaje y sus componentes o referencias hacia los sistemas especializados. No deberá duplicar el estado ni la semántica que pertenecen a Atributos, Salud, Relaciones, Conocimiento, Profesiones, Propiedad, Inventario, Reputación u otros dominios.

## Debe permitir

- crear personajes;
- diferenciar personaje jugador y NPC;
- mantener identidad persistente;
- almacenar nombre, sexo, raza, edad y procedencia;
- permitir asociar al personaje los componentes y referencias gestionados por el Sistema de Atributos, Habilidades, Competencias, Aprendizaje y Progresión;
- permitir asociar el estado fisico gestionado por el Sistema de Salud, Heridas, Enfermedades y Estado Físico;
- permitir referenciar heridas, enfermedades y otros estados sin duplicar la autoridad del Sistema de Salud;
- permitir asociar necesidades y rutinas gestionadas por el Sistema de Necesidades, Rutinas y Vida Cotidiana;
- permitir asociar habilidades y competencias gestionadas por su sistema propietario;
- permitir que la progresión y el aprendizaje modifiquen al personaje mediante el sistema propietario correspondiente;
- gestionar rasgos de personalidad;
- gestionar temperamento y tendencias;
- gestionar valores, intereses y motivaciones;
- mantener referencias a profesión y ocupación gestionadas por el Sistema de Profesiones, Trabajos y Ocupaciones;
- mantener referencias al estatus y posición social calculados o mantenidos por sus sistemas propietarios;
- mantener referencias a riqueza, cuentas, propiedades y posesiones sin duplicar los estados de Economía y Propiedad;
- mantener referencias a pertenencias organizativas gestionadas por el Sistema de Organizaciones y Facciones;
- mantener referencias a relaciones familiares gestionadas por el Sistema de Relaciones;
- mantener referencias a relaciones sociales gestionadas por el Sistema de Relaciones;
- permitir que el Sistema de Relaciones vincule al personaje con amistades, rivalidades, enemistades y vínculos afectivos;
- permitir que pareja, matrimonio y descendencia se representen mediante entidades y relaciones reales en sus sistemas propietarios;
- reflejar nacimiento, vida, muerte y demás cambios vitales producidos por los sistemas propietarios correspondientes;
- mantener personajes fallecidos como entidades históricas;
- mantener referencia al inventario personal gestionado por el Sistema de Objetos, Inventario y Equipamiento;
- mantener referencia al equipamiento gestionado por el Sistema de Objetos, Inventario y Equipamiento;
- mantener referencia a la reputación gestionada por el Sistema de Reputación, Prestigio e Imagen Pública;
- mantener referencia al conocimiento individual gestionado por el Sistema de Conocimiento;
- mantener rasgos biográficos estables y referencias a acontecimientos relevantes sin sustituir al Sistema de Conocimiento ni al Sistema de Historia y Crónica del Mundo;
- permitir referenciar delitos, acusaciones y antecedentes mantenidos por Crimen, Justicia y Conocimiento cuando corresponda;
- permitir estados temporales y permanentes;
- permitir que los personajes cambien a lo largo de años o generaciones;
- soportar personajes definidos manualmente;
- soportar personajes generados proceduralmente;
- permitir personajes creados durante la propia simulación;
- permitir que el Sistema de Simulación aplique diferentes niveles de detalle lógico sin perder la identidad del personaje;
- permitir que la simulación reduzca el coste técnico de personajes secundarios sin convertir al Sistema de Personajes en scheduler;
- permitir que un personaje exista lógicamente aunque no esté cargado visualmente en el mapa;
- proporcionar información común a los sistemas especializados sin concentrar toda su lógica dentro de este sistema;
- integrarse con guardado y carga;
- funcionar de forma idéntica a nivel lógico en Windows y Android.
## Depende de

- Núcleo de Partida
- Sistema de Entidades e Identidad
- Sistema de Estado del Mundo
- Sistema de Tiempo
- Sistema de Datos, Configuración y Content Packs
## Lo utilizan

- Sistema de Personaje Jugador, Creación de Personaje y Nueva Partida
- Sistema de NPC
- Relationships
- Knowledge System
- Generations
- Organizations
- Economy
- Crime System
- Combat
- Inventory
- Dialogues
- Reputation
- Professions
- Director
- Quests
- Events
- Partida Maestra/Magíster
## Reutilización

RPG Core configurable. La estructura base de personajes, su identidad, datos intrínsecos, composición por componentes y referencias estables hacia sistemas especializados deberá ser reutilizable. Los dominios especializados conservarán siempre la propiedad de sus propios datos. Razas, longevidad, atributos concretos, reglas biológicas, profesiones, culturas y cualquier característica específica de Nimroel deberán proporcionarse mediante datos y reglas configurables del universo.

## Documentación técnica

Obligatoria. Codex deberá crear y mantener la documentación técnica del sistema a medida que lo implemente y modifique. La documentación deberá reflejar exclusivamente la implementación real existente en el repositorio e incluir, como mínimo:

- arquitectura;
- clases y componentes;
- archivos;
- estructuras y enums;
- API pública;
- flujo de datos;
- inicialización;
- dependencias;
- comunicación con otros sistemas;
- persistencia;
- decisiones técnicas relevantes;
- diferencias entre Windows y Android cuando existan;
- pruebas y validaciones;
- limitaciones conocidas;
- elementos pertenecientes al RPG Core reutilizable;
- dependencias específicas de Nimroel;
- instrucciones necesarias para portar o reutilizar el sistema en otro videojuego. La documentación deberá mantenerse actualizada y versionada junto con el código.
## Estado

Pendiente
