# 5 · SISTEMA DE TIEMPO

## Qué es

Controla el paso del tiempo dentro de la partida y proporciona una referencia temporal común para todos los sistemas del juego. Debe permitir que Nimroel funcione como un mundo persistente y coherente, donde personajes, organizaciones, viajes, eventos, economía, clima, generaciones y consecuencias evolucionen según una misma cronología.

## Debe permitir

- mantener fecha y hora actuales de la partida;
- utilizar el calendario y las reglas temporales definidos por la configuración o los Content Packs del universo;
- controlar velocidad del tiempo;
- pausar y reanudar el tiempo;
- acelerar o ralentizar el paso del tiempo cuando proceda;
- convertir tiempo real en tiempo de juego;
- programar operaciones, vencimientos o activaciones futuras; notificar a los sistemas propietarios cuando alcance la fecha u hora correspondiente, sin ejecutar por sí mismo la lógica funcional de dichos sistemas;
- controlar duraciones;
- gestionar esperas;
- proporcionar referencias, duraciones e intervalos temporales para viajes y otras actividades;
- proporcionar cálculos temporales necesarios para edades, crecimiento y envejecimiento;
- proporcionar soporte temporal a nacimientos, muertes, embarazos y demás procesos vitales, dejando su lógica y estado en los sistemas propietarios correspondientes;
- permitir actividades que consuman horas, días, meses o años;
- mantener eventos periódicos;
- proporcionar la referencia temporal necesaria para estaciones y ciclos diarios;
- proporcionar soporte temporal para horarios de NPC, comercios, instituciones y otras actividades programadas, sin apropiarse de su lógica de funcionamiento;
- controlar vencimientos, plazos y consecuencias temporales;
- permitir representar y calcular intervalos temporales largos para que el Sistema de Simulación pueda procesar la evolución del mundo sin que el Sistema de Tiempo asuma dicha simulación;
- mantener coherencia temporal al guardar y cargar una partida;
- proporcionar marcas temporales para acontecimientos históricos;
- permitir consultar cuánto tiempo ha pasado desde cualquier evento relevante.
## Depende de

- Núcleo de Partida
- Sistema de Estado del Mundo
- Sistema de Datos, Configuración y Content Packs
## Lo utilizan

- Character System
- NPC
- Director
- Organizations
- Economy
- Crime System
- Knowledge System
- Generations
- Climate System
- Travel System
- Events
- Quests
- Combat
- Agriculture
- Trade
- Save/Load
- Partida Maestra/Magíster
## Reutilización

RPG Core configurable.

La gestión del paso del tiempo, eventos temporales, duraciones, programación y cronología deberá ser reutilizable. El calendario, duración de días, meses, años, estaciones y cualquier regla temporal específica de Nimroel deberán mantenerse como configuración del universo y no integrarse rígidamente en el sistema base.

## Documentación técnica

Obligatoria. Codex deberá crear y mantener la documentación técnica del sistema a medida que lo implemente y modifique. La documentación deberá reflejar exclusivamente la implementación real existente en el repositorio e incluir, como mínimo:

- arquitectura;
- clases y componentes;
- archivos;
- estructuras y enums;
- API pública;
- flujo de datos;
- inicialización;
- dependencias;
- comunicación con otros sistemas;
- persistencia;
- decisiones técnicas relevantes;
- diferencias entre Windows y Android cuando existan;
- pruebas y validaciones;
- limitaciones conocidas;
- elementos pertenecientes al RPG Core reutilizable;
- dependencias específicas de Nimroel;
- instrucciones necesarias para portar o reutilizar el sistema en otro videojuego. La documentación deberá mantenerse actualizada y versionada junto con el código.
## Estado

Pendiente
