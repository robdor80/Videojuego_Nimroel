# 29 · SISTEMA DE OBJETOS, INVENTARIO Y EQUIPAMIENTO

## Qué es

Gestiona todos los objetos fisicos relevantes que pueden existir, poseerse, almacenarse, utilizarse, transportarse, equiparse, comerciarse, perderse, robarse o destruirse dentro del mundo. Debe separar la definición genérica de un tipo de objeto de cada ejemplar concreto existente en una partida, permitiendo que determinados objetos tengan identidad, propietario, procedencia, estado, historia y características propias.

## Debe permitir

- definir tipos de objetos;
- crear ejemplares concretos de objetos;
- asignar identidad persistente a objetos cuando sea necesario;
- distinguir objetos genéricos de objetos únicos;
- permitir múltiples unidades de un mismo objeto;
- permitir objetos apilables;
- permitir objetos no apilables;
- definir peso;
- definir volumen cuando sea relevante;
- definir valor económico;
- definir calidad;
- definir estado;
- definir durabilidad cuando corresponda;
- definir rareza cuando el diseño lo contemple;
- definir materiales;
- definir categorías;
- definir etiquetas y propiedades;
- definir requisitos de uso;
- definir restricciones culturales, legales o profesionales;
- definir objetos consumibles;
- definir herramientas;
- definir armas;
- definir armaduras;
- definir ropa;
- definir alimentos;
- definir medicinas;
- definir documentos;
- definir libros;
- definir cartas;
- definir llaves;
- definir recursos;
- definir materias primas;
- definir productos elaborados;
- definir objetos de misión;
- definir objetos ceremoniales;
- definir objetos de valor;
- definir reliquias;
- permitir nuevas categorías sin modificar la arquitectura base;
- gestionar inventario del personaje jugador;
- gestionar inventarios de NPC;
- gestionar inventarios de organizaciones;
- gestionar inventarios de propiedades;
- gestionar inventarios de establecimientos;
- gestionar almacenes;
- gestionar cofres, contenedores y otros espacios de almacenamiento;
- permitir contenedores dentro de otros contenedores cuando el diseño lo permita;
- limitar capacidad por peso;
- limitar capacidad por volumen cuando sea necesario;
- limitar capacidad por número de objetos cuando proceda;
- permitir inventarios sin representación visual directa;
- permitir inventarios simplificados para entidades lejanas;
- mover objetos entre inventarios;
- recoger objetos;
- soltar objetos;
- entregar objetos;
- recibir objetos;
- almacenar objetos;
- retirar objetos;
- destruir objetos;
- consumir objetos;
- dividir pilas;
- combinar pilas compatibles;
- impedir combinaciones cuando los ejemplares tengan propiedades diferentes;
- mantener propietario legal;
- mantener poseedor actual;
- integrarse con el Sistema de Propiedad y Posesiones;
- permitir objetos robados;
- permitir objetos perdidos;
- permitir objetos abandonados;
- permitir objetos confiscados;
- permitir objetos prestados;
- permitir objetos depositados;
- mantener procedencia cuando sea relevante;
- registrar creador o fabricante;
- registrar lugar de fabricación;
- registrar fecha de creación cuando sea relevante;
- registrar propietarios anteriores cuando corresponda;
- mantener historia propia de objetos importantes;
- permitir que un objeto adquiera relevancia histórica durante la partida;
- permitir nombres propios para objetos únicos;
- permitir modificaciones;
- permitir mejoras;
- permitir reparaciones;
- permitir deterioro;
- permitir rotura;
- permitir destrucción definitiva;
- permitir objetos dañados;
- permitir pérdida de calidad;
- permitir cambios de valor según estado;
- permitir equipamiento;
- definir espacios de equipamiento;
- equipar armas;
- equipar armaduras;
- equipar ropa;
- equipar herramientas;
- equipar accesorios cuando el diseño los contemple;
- comprobar requisitos antes de equipar;
- impedir combinaciones incompatibles;
- modificar atributos o capacidades mientras un objeto esté equipado;
- aplicar efectos temporales;
- aplicar efectos permanentes cuando corresponda;
- permitir objetos con usos limitados;
- permitir munición u otros consumibles asociados si el universo lo requiere;
- gestionar armas de acuerdo con el sistema de combate;
- gestionar protección de acuerdo con el sistema de combate;
- permitir objetos necesarios para determinadas profesiones;
- permitir herramientas necesarias para procesos productivos;
- permitir objetos necesarios para acceder a determinadas localizaciones;
- permitir llaves y permisos fisicos;
- permitir documentos que acrediten identidad, propiedad, cargo o autorización;
- permitir libros, cartas y documentos como fuentes del Sistema de Conocimiento;
- permitir que leer un objeto documental transmita información;
- permitir información falsa contenida en documentos;
- permitir objetos ocultos;
- permitir objetos secretos;
- permitir búsqueda de objetos;
- permitir registro de personajes o lugares cuando otros sistemas lo autoricen;
- permitir ocultar objetos;
- permitir contrabando;
- permitir objetos ilegales;
- permitir objetos restringidos;
- integrarse con crimen y justicia;
- integrarse con comercio;
- integrarse con economía;
- integrarse con producción;
- integrarse con profesiones;
- integrarse con propiedad;
- integrarse con localizaciones;
- integrarse con combate;
- integrarse con conocimiento;
- integrarse con eventos y misiones;
- permitir loot cuando corresponda;
- impedir generación arbitraria de objetos que rompa la coherencia económica;
- permitir que objetos procedan de producción, comercio, herencia, saqueo, hallazgo u otras fuentes válidas;
- permitir generación procedural controlada cuando el diseño lo requiera;
- mantener coherencia entre objetos fisicos y estado del mundo;
- permitir que un objeto exista lógicamente aunque no esté representado visualmente en una escena;
- crear representación visual únicamente cuando sea necesaria;
- destruir la representación visual sin destruir necesariamente el objeto lógico;
- permitir objetos colocados fisicamente en localizaciones;
- registrar ubicación de objetos relevantes;
- permitir objetos perdidos o escondidos durante largos periodos;
- permitir que NPC utilicen objetos de sus inventarios;
- permitir que NPC busquen herramientas o recursos que necesiten;
- impedir que NPC utilicen objetos que no poseen o no pueden localizar;
- utilizar el Sistema de Conocimiento para determinar si un personaje sabe dónde está un objeto;
- permitir que NPC desconozcan el contenido de determinados contenedores;
- permitir inventarios privados;
- permitir inventarios compartidos;
- permitir permisos de acceso;
- mantener interfaz de inventario adaptada a ratón y teclado en Windows;
- mantener interfaz de inventario completamente operable mediante control táctil en Android;
- permitir arrastrar y soltar cuando sea apropiado;
- ofrecer alternativas táctiles a cualquier acción basada en arrastre, clic derecho o hover;
- permitir incorporación de nuevos catálogos de objetos por región;
- permitir que Norgard incluya inicialmente únicamente sus objetos, recursos, armas, herramientas y bienes;
- permitir añadir posteriormente objetos propios de otros territorios humanos y territorios élficos sin modificar la arquitectura del sistema;
- mantener separados los datos de objetos propios de Nimroel de la infraestructura técnica reutilizable;
- proporcionar al Director información sobre objetos relevantes, pérdidas, robos, reliquias y cambios de propiedad;
- permitir que Magíster utilice objetos e inventarios como contexto narrativo sin alterar directamente su estado real;
- conservar inventarios, objetos únicos, propiedades, estados e historial mediante guardado y carga.
## Depende de

- Núcleo de Partida
- Sistema de Estado del Mundo
- Sistema de Tiempo
- Sistema de Entidades e Identidad
- Sistema de Plataforma, Dispositivo y Escalado
- Sistema de Entrada y Controles
- Sistema de Interfaz de Usuario (UI/UX)
- Sistema de Personajes
- Sistema de NPC
- Sistema de Conocimiento
- Sistema de Organizaciones y Facciones
- Sistema de Localizaciones y Estructura del Mundo
- Sistema de Propiedad y Posesiones
- Sistema de Economía y Recursos
- Sistema de Producción, Artesanía y Transformación
## Lo utilizan

- Sistema de Personaje Jugador, Creación de Personaje y Nueva Partida
- Sistema de NPC
- Sistema de Personajes
- Combat
- Equipment System
- Economy
- Trade System
- Production System
- Professions
- Property System
- Crime System
- Sistema de Justicia, Leyes y Jurisdicciones
- Knowledge System
- Exploration
- Loot System
- Events
- Quests
- Director
- Sistema de Historia y Crónica del Mundo
- Partida Maestra/Magíster
## Reutilización

RPG Core configurable. La infraestructura destinada a definir objetos, crear ejemplares, gestionar inventarios, contenedores, equipamiento, estado, durabilidad, propiedad, transferencias y representación lógica deberá ser reutilizable.

Los objetos concretos, armas, armaduras, herramientas, recursos, materiales, valores, categorías, efectos, requisitos y demás contenido propio de Nimroel deberán definirse externamente mediante datos y configuración del universo. El sistema deberá admitir catálogos de contenido independientes por universo y por región, permitiendo que Norgard constituya inicialmente el contenido disponible y que futuros territorios humanos, territorios élficos u otras regiones incorporen nuevos objetos sin modificar el RPG Core.

## Documentación técnica

Obligatoria. Codex deberá crear y mantener la documentación técnica del sistema a medida que lo implemente y modifique. La documentación deberá reflejar exclusivamente la implementación real existente en el repositorio e incluir, como mínimo:

- arquitectura;
- clases y componentes;
- archivos;
- estructuras y enums;
- API pública;
- flujo de datos;
- inicialización;
- dependencias;
- comunicación con otros sistemas;
- persistencia;
- decisiones técnicas relevantes;
- diferencias entre Windows y Android cuando existan;
- pruebas y validaciones;
- limitaciones conocidas;
- elementos pertenecientes al RPG Core reutilizable;
- dependencias específicas de Nimroel;
- instrucciones necesarias para portar o reutilizar el sistema en otro videojuego. La documentación deberá mantenerse actualizada y versionada junto con el código.
## Estado

Pendiente
