# 28 · SISTEMA DE PROPIEDAD Y POSESIONES

## Qué es

Gestiona quién posee, controla, utiliza, administra o reclama cualquier bien relevante dentro del mundo. Debe distinguir entre propiedad legal, posesión fisica, control efectivo, derechos de uso y reclamaciones, permitiendo que personajes, familias, organizaciones e instituciones puedan adquirir, perder, heredar, transferir o disputar bienes a lo largo de la partida.

## Debe permitir

- registrar propiedades persistentes;
- identificar de forma única cada propiedad;
- distinguir distintos tipos de propiedad;
- gestionar propiedad de terrenos;
- gestionar propiedad de edificios;
- gestionar propiedad de viviendas;
- gestionar propiedad de establecimientos;
- gestionar propiedad de instalaciones;
- gestionar propiedad de objetos relevantes;
- gestionar propiedad de animales, vehículos u otros activos cuando existan;
- gestionar propiedad de recursos;
- gestionar propiedad de dinero y activos financieros;
- asignar propietarios individuales;
- asignar propiedades compartidas;
- asignar propiedades a familias;
- asignar propiedades a organizaciones;
- asignar propiedades a instituciones;
- distinguir propietario de poseedor actual;
- distinguir propiedad legal de control efectivo;
- distinguir propietario de administrador;
- permitir derechos de uso sin transferencia de propiedad;
- permitir usufructos, concesiones o equivalentes cuando las reglas del universo lo contemplen;
- permitir alquileres;
- permitir cesiones temporales;
- permitir préstamos de bienes;
- permitir depósitos o custodia;
- registrar adquisición de propiedades;
- registrar compraventas;
- registrar donaciones;
- registrar intercambios;
- registrar herencias;
- registrar confiscaciones;
- registrar expropiaciones cuando proceda;
- registrar robos;
- registrar pérdidas;
- registrar abandono de bienes;
- permitir apropiación de bienes abandonados según las reglas aplicables;
- gestionar titulos o documentos de propiedad cuando existan;
- mantener historial de propietarios;
- mantener historial de transferencias;
- registrar fecha y causa de cada cambio de propiedad;
- permitir disputas de propiedad;
- permitir múltiples reclamantes sobre un mismo bien;
- permitir reclamaciones hereditarias;
- permitir reclamaciones territoriales;
- permitir ocupación de propiedades;
- gestionar propiedades tomadas durante guerras o conflictos;
- distinguir conquista o control territorial de transferencia legal de propiedad;
- permitir devolución de propiedades;
- permitir restituciones;
- permitir confiscaciones como consecuencia de delitos o sentencias;
- integrarse con crimen y justicia para determinar cuándo una apropiación constituye delito;
- permitir bienes robados;
- mantener conocimiento sobre procedencia de bienes cuando corresponda;
- permitir ocultar la verdadera propiedad de determinados bienes;
- permitir testaferros, propietarios aparentes o mecanismos equivalentes si el diseño los contempla;
- gestionar bienes comunes;
- gestionar patrimonio familiar;
- gestionar patrimonio institucional;
- gestionar patrimonio de organizaciones;
- calcular patrimonio de personajes y entidades;
- permitir valoración económica de propiedades;
- permitir que el valor de un bien cambie con el tiempo;
- proporcionar información al sistema económico;
- permitir impuestos asociados a propiedades cuando proceda;
- permitir deudas garantizadas mediante bienes si el sistema económico lo contempla;
- permitir embargo de propiedades;
- permitir transmisión automática mediante herencia;
- integrarse con generaciones y legado;
- permitir división de patrimonio entre herederos;
- permitir propiedades indivisibles;
- permitir disputas sucesorias;
- gestionar residencia sin propiedad;
- gestionar lugar de trabajo sin propiedad;
- gestionar establecimientos explotados por una entidad distinta de su propietario;
- asociar propiedades a localizaciones;
- permitir que una propiedad exista aunque su representación visual no esté cargada;
- permitir propiedades destruidas sin eliminar necesariamente su historial legal;
- permitir reconstrucción de propiedades;
- permitir cambio de uso de un inmueble o terreno;
- permitir pérdida de valor por destrucción, guerra u otros acontecimientos;
- permitir propiedades privadas, públicas, comunales o institucionales;
- permitir restricciones culturales, legales o sociales sobre quién puede poseer determinados bienes;
- permitir que NPC tomen decisiones relacionadas con adquisición o pérdida de propiedades;
- influir en riqueza y posición social;
- influir en relaciones;
- influir en reputación;
- influir en conflictos familiares;
- influir en política;
- influir en economía;
- influir en crimen;
- permitir eventos relacionados con propiedad;
- permitir misiones relacionadas con herencias, compraventas, reclamaciones, robos o disputas;
- proporcionar al Director información sobre patrimonio, desigualdad, disputas y cambios relevantes;
- permitir que Magíster utilice la situación patrimonial como contexto narrativo sin alterar directamente la propiedad real;
- conservar todo el historial y estado de propiedad mediante guardado y carga.
## Depende de

- Núcleo de Partida
- Sistema de Estado del Mundo
- Sistema de Tiempo
- Sistema de Entidades e Identidad
- Sistema de Personajes
- Sistema de Relaciones
- Sistema de Generaciones y Legado
- Sistema de Organizaciones y Facciones
- Sistema de Localizaciones y Estructura del Mundo
## Lo utilizan

- Sistema de Personaje Jugador, Creación de Personaje y Nueva Partida
- Sistema de NPC
- Organizations
- Generations
- Economy
- Trade
- Crime System
- Sistema de Justicia, Leyes y Jurisdicciones
- Politics
- Reputation
- Professions
- Housing System
- Inventory
- War System
- Events
- Quests
- Director
- Sistema de Historia y Crónica del Mundo
- Partida Maestra/Magíster
## Reutilización

RPG Core configurable. La infraestructura destinada a registrar propiedad, posesión, control, derechos de uso, transferencias, herencias, reclamaciones e historial patrimonial deberá ser reutilizable. Los tipos concretos de bienes, sistemas legales de propiedad, reglas sucesorias, restricciones culturales, formas de tenencia y cualquier particularidad propia de Nimroel deberán definirse externamente mediante datos y configuración del universo.

## Documentación técnica

Obligatoria. Codex deberá crear y mantener la documentación técnica del sistema a medida que lo implemente y modifique. La documentación deberá reflejar exclusivamente la implementación real existente en el repositorio e incluir, como mínimo:

- arquitectura;
- clases y componentes;
- archivos;
- estructuras y enums;
- API pública;
- flujo de datos;
- inicialización;
- dependencias;
- comunicación con otros sistemas;
- persistencia;
- decisiones técnicas relevantes;
- diferencias entre Windows y Android cuando existan;
- pruebas y validaciones;
- limitaciones conocidas;
- elementos pertenecientes al RPG Core reutilizable;
- dependencias específicas de Nimroel;
- instrucciones necesarias para portar o reutilizar el sistema en otro videojuego. La documentación deberá mantenerse actualizada y versionada junto con el código.
## Estado

Pendiente
