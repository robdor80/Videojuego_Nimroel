# 21 · SISTEMA DE CONOCIMIENTO

## Qué es

Gestiona qué sabe, cree, desconoce o interpreta cada personaje, organización o institución. La verdad objetiva de lo que existe y ocurre pertenece al World State y a los sistemas propietarios; este sistema mantiene únicamente representaciones de conocimiento, creencia, incertidumbre y procedencia. Debe separar de forma estricta la verdad objetiva del World State del conocimiento disponible para cada entidad, evitando que NPC, jugador o sistemas secundarios accedan automáticamente a información que no deberían conocer.

## Debe permitir

- mantener separada la verdad del mundo del conocimiento de cada personaje;
- registrar conocimiento individual;
- registrar conocimiento institucional;
- registrar la procedencia de una información;
- saber cuándo y cómo se obtuvo una información;
- distinguir información observada directamente de información recibida de terceros;
- transmitir información entre personajes;
- transmitir información entre personajes y organizaciones;
- permitir rumores;
- permitir información incompleta;
- permitir información incorrecta;
- permitir mentiras;
- permitir interpretaciones equivocadas de hechos reales;
- registrar distintos niveles de certeza;
- permitir que dos personajes tengan versiones diferentes de un mismo acontecimiento;
- permitir que una organización conozca algo que algunos de sus miembros desconozcan;
- permitir secretos;
- controlar quién conoce un secreto;
- permitir filtraciones de información;
- permitir espionaje y obtención clandestina de información;
- permitir documentos, cartas, testimonios y otras fuentes de conocimiento;
- permitir que información antigua quede desactualizada;
- permitir descubrir que una información previa era falsa;
- actualizar conocimientos cuando aparecen nuevas evidencias;
- conservar el historial de cómo evolucionó una creencia cuando sea relevante;
- influir en decisiones de NPC según lo que creen que ocurre, no según la verdad absoluta;
- influir en relaciones personales;
- influir en política y diplomacia;
- influir en comercio y economía;
- influir en investigaciones criminales;
- influir en denuncias, acusaciones y juicios;
- influir en misiones y acontecimientos;
- impedir que el jugador reciba información que su personaje todavía no conoce;
- proporcionar una capa player-safe para UI, mapas y diálogos;
- controlar descubrimiento de lugares;
- controlar conocimiento de personajes;
- controlar conocimiento sobre organizaciones;
- controlar conocimiento histórico;
- permitir conocimientos heredados o transmitidos entre generaciones;
- permitir pérdida de conocimiento cuando mueren personajes;
- conservar conocimiento cuando haya sido documentado o institucionalizado;
- permitir desaparición definitiva de conocimientos si no queda ninguna fuente viva o documental;
- alimentar rumores y transmisión social de información;
- permitir que el Director consulte diferencias entre verdad y percepción;
- proporcionar a Magíster únicamente el contexto apropiado cuando no deba recibir información completa;
- impedir filtraciones accidentales desde World State hacia sistemas destinados al jugador;
- mantener todo el conocimiento de forma persistente mediante guardado y carga.
## Depende de

- Núcleo de Partida
- Sistema de Estado del Mundo
- Sistema de Tiempo
- Sistema de Entidades e Identidad
- Sistema de Personajes
- Sistema de Relaciones
## Lo utilizan

- Sistema de NPC
- Sistema de Interfaz de Usuario (UI/UX)
- Maps
- Dialogues
- Organizations
- Crime System
- Reputation
- Economy
- Politics
- Diplomacy
- Quests
- Events
- Generations
- Director
- Partida Maestra/Magíster
- Player-Safe Exporter
## Reutilización

RPG Core configurable. La separación entre verdad del mundo, conocimiento individual, conocimiento institucional, rumores, errores, secretos y procedencia de la información deberá formar parte del RPG Core.

Los hechos concretos, instituciones, fuentes de información, reglas culturales y contenidos propios de Nimroel deberán permanecer fuera del sistema técnico genérico.

## Documentación técnica

Obligatoria. Codex deberá crear y mantener la documentación técnica del sistema a medida que lo implemente y modifique. La documentación deberá reflejar exclusivamente la implementación real existente en el repositorio e incluir, como mínimo:

- arquitectura;
- clases y componentes;
- archivos;
- estructuras y enums;
- API pública;
- flujo de datos;
- inicialización;
- dependencias;
- comunicación con otros sistemas;
- persistencia;
- decisiones técnicas relevantes;
- diferencias entre Windows y Android cuando existan;
- pruebas y validaciones;
- limitaciones conocidas;
- elementos pertenecientes al RPG Core reutilizable;
- dependencias específicas de Nimroel;
- instrucciones necesarias para portar o reutilizar el sistema en otro videojuego. La documentación deberá mantenerse actualizada y versionada junto con el código.
## Estado

Pendiente
