# 1 · NÚCLEO DE PARTIDA

## Qué es

Es la base estructural de una partida de Nimroel dentro de Unreal Engine 5. Mantiene la identidad de la partida activa y coordina la inicialización, carga, ejecución y cierre de los sistemas principales del juego. Actúa como punto central desde el que el resto de sistemas pueden localizar los datos y servicios correspondientes a la partida actual, evitando que cada sistema funcione de manera aislada.

## Debe permitir

- coordinar técnicamente la creación de una nueva partida, delegando en los sistemas propietarios la generación, configuración y creación de su contenido y estado;
- cargar una partida existente;
- mantener un identificador único de partida;
- distinguir entre datos globales del juego y datos propios de una partida;
- registrar los sistemas necesarios, resolver sus dependencias y coordinar su inicialización, activación y cierre en el orden correcto;
- mantener acceso coordinado a los sistemas principales activos, sin asumir la propiedad de sus datos ni de sus responsabilidades de dominio;
- controlar los estados generales de la partida;
- gestionar entrada y salida de una sesión de juego;
- coordinar carga y descarga de mundos/mapas;
- proporcionar acceso común al estado de la partida;
- permitir que los diferentes sistemas se comuniquen sin quedar fuertemente acoplados entre sí mediante infraestructura técnica común del RPG Core, incluyendo mecanismos de eventos, mensajes o servicios internos cuando corresponda;
- preparar la arquitectura para partidas de larga duración;
- permitir ampliaciones futuras sin tener que reconstruir el núcleo;
- servir como punto de conexión entre UE5, persistencia y los sistemas externos que puedan existir.
## Depende de

- Ninguno.
- Es la capa base sobre la que se construirán los demás sistemas.
## Lo utilizan

- Todos los sistemas principales del juego.
- Especialmente:
- World State
- Save/Load
- Time System
- Director
- Character System
- NPC
- Organizations
- Economy
- Crime System
- Generations
- Maps
- AI Systems
- Partida Maestra/Magíster
## Reutilización

RPG Core. Debe diseñarse como núcleo técnico completamente independiente del universo de Nimroel. No deberá contener personajes, razas, lugares, organizaciones, narrativa, reglas de lore ni ningún otro contenido específico de Nimroel. Deberá poder utilizarse como base de futuros videojuegos construidos sobre la misma arquitectura RPG.

## Documentación técnica

Obligatoria. Codex deberá crear y mantener la documentación técnica del sistema a medida que lo implemente y modifique. La documentación deberá reflejar exclusivamente la implementación real existente en el repositorio e incluir, como mínimo:

- arquitectura;
- clases y componentes;
- archivos;
- estructuras y enums;
- API pública;
- flujo de datos;
- inicialización;
- dependencias;
- comunicación con otros sistemas;
- persistencia;
- decisiones técnicas relevantes;
- diferencias entre Windows y Android cuando existan;
- pruebas y validaciones;
- limitaciones conocidas;
- elementos pertenecientes al RPG Core reutilizable;
- dependencias específicas de Nimroel;
- instrucciones necesarias para portar o reutilizar el sistema en otro videojuego. La documentación deberá mantenerse actualizada y versionada junto con el código.
## Estado

Pendiente
